/**
 * Rutas con puntos para campos anidados (§8.1): `headline`, `cta.label`, `items.2.title`.
 * Los segmentos numéricos indexan arreglos. Todas las escrituras son inmutables.
 */
export type ArrayOp = 'add' | 'duplicate' | 'remove' | 'move_up' | 'move_down';
export declare function splitPath(path: string): string[];
/** Une segmentos ignorando vacíos: joinPath('items', 2, 'title') → "items.2.title". */
export declare function joinPath(...parts: Array<string | number | null | undefined>): string;
export declare function getPath<T = any>(obj: any, path: string): T | undefined;
/** Copia con `value` en `path`; crea objetos/arreglos intermedios y conserva los hermanos. */
export declare function setPath<T = any>(obj: T, path: string, value: any): T;
/** Copia sin la clave (o el elemento del arreglo) en `path`. */
export declare function deletePath<T = any>(obj: T, path: string): T;
/** Valor vacío con la misma forma que `sample` (para agregar un elemento a un repetidor). */
export declare function emptyLike(sample: any): any;
/**
 * Aplica una operación de repetidor (§8.2 ARRAY_ITEM_ACTION) a `data[arrayPath]`.
 * `add` inserta después de `index` (-1 = al inicio) un elemento vacío con la forma de sus hermanos
 * o `template` si se pasa (el portal usa los valores por defecto del catálogo).
 */
export declare function applyArrayOp<T = any>(data: T, arrayPath: string, index: number, op: ArrayOp, template?: any): T;
