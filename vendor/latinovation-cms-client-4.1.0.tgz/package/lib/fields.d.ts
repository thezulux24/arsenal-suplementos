import type { BlockSchema, FieldSchema, FieldType, LinkValue } from './types.js';
/** Texto de un valor primitivo ('' para objetos, null o undefined). */
export declare function str(v: unknown): string;
/** true si el valor no aporta nada que mostrar. */
export declare function isEmptyValue(v: unknown): boolean;
/** `image` → `imageAlt`; `items.0.image` → `items.0.imageAlt`. */
export declare function imageAltPath(path: string): string;
/** `image` → `imageFocal` ("50% 30%", se aplica como object-position). */
export declare function imageFocalPath(path: string): string;
/** true si `key` es un compañero `…Alt`/`…Focal` de otro campo presente en `siblings`. */
export declare function isImageCompanion(key: string, siblings?: Record<string, any>): boolean;
/** Normaliza un foco ("50% 30%", "50,30", {x,y}) a `object-position` válido o ''. */
export declare function focalToObjectPosition(v: unknown): string;
export interface ImageFieldValue {
    src: string;
    alt: string;
    objectPosition: string;
}
/**
 * Lee una imagen con sus compañeros: `imageField(data, 'items.0.image')`.
 * Acepta también valores objeto `{ url|src, alt, focal }`.
 */
export declare function imageField(data: any, path: string, fallbackAlt?: string): ImageFieldValue;
/** Imágenes de un campo galería (texto separado por comas/saltos/`|`, o arreglo de strings/objetos). */
export declare function galleryField(v: unknown): Array<{
    url: string;
    alt: string;
}>;
/** Acepta `{label,href,newTab}`, `{text,url}` o un string (href). */
export declare function normalizeLink(v: unknown): LinkValue;
/** href seguro para el navegador ('' si es javascript:, data:, etc.). Relativos simples se aceptan. */
export declare function safeHref(href: string | undefined): string;
export declare function getBlockSchema(block: string | null | undefined): BlockSchema | undefined;
/** Esquema del campo en `path` para un bloque (ignora índices): fieldSchema('faq.accordion', 'items.0.answer'). */
export declare function fieldSchema(block: string | null | undefined, path: string): FieldSchema | undefined;
/** Tipo probable de un campo sin esquema, por su valor y su nombre. */
export declare function inferFieldType(value: unknown, key?: string): FieldType;
/** Tipo de un campo de sección: esquema del catálogo si existe; si no, inferido del valor. */
export declare function resolveFieldType(block: string | null | undefined, path: string, value: unknown): FieldType;
export declare function escapeHtml(s: string): string;
/** Markdown → HTML seguro: títulos, párrafos, listas, citas, separadores, énfasis y enlaces. */
export declare function markdownToHtml(md: string): string;
/** Texto plano de Markdown (para metadescripciones y vistas previas). */
export declare function markdownToText(md: string): string;
