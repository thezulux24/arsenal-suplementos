import type { ElementStyle, SectionData, SectionStyle } from './types.js';
/**
 * CSS por sección a partir de `data._style` (§8.3), `data._elementStyles` (estilos por elemento
 * `[data-el-id]`) y `data._customCss` (saneado y acotado a la sección).
 * Mismo resultado visual que `buildSectionElementCss` del renderer del CMS para las claves genéricas.
 */
export interface SectionCssInput {
    key: string;
    data?: SectionData | null;
}
export interface SectionCssOptions {
    /** Modo editor: las secciones ocultas por dispositivo se ven atenuadas en vez de desaparecer. */
    isBuilder?: boolean;
    /** Selector raíz (por defecto `[data-section-key="<key>"]`). */
    selector?: string;
    /** Punto de corte móvil/escritorio en px (por defecto 768). */
    breakpoint?: number;
}
export declare const CONTENT_WIDTHS: Record<string, string>;
/** Escapa un valor para usarlo dentro de `[attr="…"]`. */
export declare function cssAttr(v: string): string;
export declare function sectionSelector(key: string): string;
/** Valor de propiedad seguro: sin llaves, `;`, `<`, `>` ni construcciones peligrosas. '' si no es usable. */
export declare function cssValue(v: unknown): string;
/** Número → `px`; cadena con unidad se respeta. */
export declare function cssLength(v: unknown): string;
export declare function cssUrl(url: unknown): string;
/**
 * Sanea CSS libre: quita comentarios, `@import`, `expression()`, `javascript:`, `-moz-binding`,
 * `behavior:` y cualquier `<…>` que pudiera cerrar la etiqueta `<style>`.
 */
export declare function sanitizeCss(css: unknown): string;
/**
 * Acota CSS a `scope`: cada selector queda bajo la sección (`&`/`:scope`/`:root` = la sección misma);
 * declaraciones sueltas (`color: red;`) se aplican a la sección. `@media`/`@supports` se recorren.
 */
export declare function scopeCss(css: string, scope: string): string;
/** Reglas de `_style` (§8.3) para la sección. */
export declare function buildSectionStyleCss(key: string, style: SectionStyle | undefined | null, opts?: SectionCssOptions): string;
/** Reglas de `_elementStyles` (estilos por `[data-el-id]`). */
export declare function buildElementStylesCss(key: string, elementStyles: Record<string, ElementStyle> | undefined | null, opts?: SectionCssOptions): string;
/**
 * CSS completo de una sección: `_style` + `_elementStyles` + `_customCss` acotado.
 * Devuelve '' si no hay nada que aplicar (no hace falta emitir `<style>`).
 */
export declare function buildSectionCss(section: SectionCssInput, opts?: SectionCssOptions): string;
/** CSS de varias secciones (p. ej. para emitir un único `<style>` en el servidor). */
export declare function buildSectionsCss(sections: SectionCssInput[], opts?: SectionCssOptions): string;
/** Ancla de la sección: `_style.anchorId` o el campo `anchor` del catálogo (sin `#`). */
export declare function sectionAnchor(data: SectionData | undefined | null): string;
/** true si `_style.hideOnMobile`/`hideOnDesktop` ocultan la sección en ambos tamaños. */
export declare function sectionHiddenEverywhere(data: SectionData | undefined | null): boolean;
