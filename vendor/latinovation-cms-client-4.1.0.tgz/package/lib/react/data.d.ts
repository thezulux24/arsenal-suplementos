import React from 'react';
import type { CollectionItem, NavLink, Product } from '../types.js';
import { type GetProductsOptions } from '../delivery.js';
import { type CollectionQuery, type CollectionQueryResult, type FilterValue, type ItemRouteOptions } from '../collections.js';
/** Productos del payload en vivo (contrato 2.5 normalizado). */
export declare function useProducts(opts?: GetProductsOptions): Product[];
/** Ítem de una colección por slug o id (del payload en vivo: refleja ediciones del portal). */
export declare function useItem<T extends CollectionItem = CollectionItem>(collection: string | undefined, itemSlug: string | undefined): T | undefined;
/** Producto normalizado por slug o id. */
export declare function useProduct(slugOrId: string | undefined, collection?: string): Product | undefined;
/** Ruta de detalle de un ítem (routeBase de la colección o `pattern`). */
export declare function useItemRoute(collection: string, item: Pick<CollectionItem, 'slug' | 'id'> | string, opts?: ItemRouteOptions): string | undefined;
export interface UseCollectionQuery<T> extends CollectionQueryResult<T> {
    query: CollectionQuery;
    setQuery(patch: Partial<CollectionQuery>): void;
    setFilter(field: string, value: FilterValue): void;
    setSearch(search: string): void;
    setSort(sort: string): void;
    setPage(page: number): void;
    reset(): void;
}
/**
 * Búsqueda, filtros (select, rango de precio, booleanos según `collectionDefinitions[col].filters`),
 * orden y paginación en el cliente sobre la colección del payload en vivo.
 * El argumento es el estado inicial; cambia el estado con los setters.
 */
export declare function useCollectionQuery<T extends CollectionItem = CollectionItem>(initial?: CollectionQuery): UseCollectionQuery<T>;
type Rest = Omit<React.HTMLAttributes<HTMLElement>, 'children'> & Record<string, any>;
/** Envuelve una tarjeta/ficha de ítem: marca `data-cms-item` y da contexto a CmsItemText/CmsItemImage. */
export declare function CmsItem({ item, collection, as: Tag, children, ...rest }: Rest & {
    item: Record<string, any> & {
        id: string;
    };
    collection?: string;
    as?: React.ElementType;
    children?: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export interface CmsItemTextProps extends Rest {
    item?: Record<string, any> & {
        id: string;
    };
    /** Campo del ítem (`title`, `brand`, `summary`, `price`…). */
    f: string;
    collection?: string;
    as?: React.ElementType;
    fallback?: string;
    multiline?: boolean;
    /** Con formato (p. ej. precio) el campo se edita desde el editor del ítem. */
    format?: (value: unknown, item: Record<string, any>) => string;
    editable?: boolean;
}
/** Texto de un ítem de colección: en línea → INLINE_COLLECTION_ITEM_CHANGE; con formato → FOCUS_COLLECTION_ITEM. */
export declare function CmsItemText({ item, f, collection, as: Tag, fallback, multiline, format, editable, className, ...rest }: CmsItemTextProps): import("react/jsx-runtime").JSX.Element | null;
export interface CmsItemImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'src'> {
    item?: Record<string, any> & {
        id: string;
    };
    /** Campo de imagen (por defecto `imageUrl`, con respaldo `image` y la primera de `gallery`). */
    f?: string;
    collection?: string;
    as?: React.ElementType;
    /** Índice de `gallery` si `f="gallery"`. */
    index?: number;
}
/** Imagen de un ítem; en el editor un clic abre el editor del ítem en ese campo (FOCUS_COLLECTION_ITEM). */
export declare function CmsItemImage({ item, f, collection, as: Img, index, alt, style, ...rest }: CmsItemImageProps): import("react/jsx-runtime").JSX.Element | null;
/** Botón (solo editor) para crear un ítem en la colección → CREATE_COLLECTION_ITEM. */
export declare function CmsAddItem({ collection, category, label, className }: {
    collection?: string;
    category?: string;
    label?: string;
    className?: string;
}): import("react/jsx-runtime").JSX.Element | null;
/** Valor de `global` en vivo (ruta con puntos). */
export declare function useGlobal<T = any>(path: string, fallback?: T): T;
export interface CmsGlobalTextProps extends Rest {
    f: string;
    as?: React.ElementType;
    fallback?: string;
    multiline?: boolean;
    editable?: boolean;
    format?: (value: unknown) => string;
}
/** Texto de `globalData` (marca, horario, dirección…). En línea → INLINE_GLOBAL_CHANGE; si no → FOCUS_GLOBAL. */
export declare function CmsGlobalText({ f, as: Tag, fallback, multiline, editable, format, className, ...rest }: CmsGlobalTextProps): import("react/jsx-runtime").JSX.Element | null;
/** Imagen de `globalData` (logo, sello…). En el editor, un clic → FOCUS_GLOBAL. */
export declare function CmsGlobalImage({ f, as: Img, alt, ...rest }: Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'src'> & {
    f: string;
    as?: React.ElementType;
}): import("react/jsx-runtime").JSX.Element | null;
export type NavList = 'header' | 'footer';
/** Enlaces visibles del menú con su índice original (el que espera el portal). */
export declare function useNavLinks(list?: NavList): Array<NavLink & {
    index: number;
}>;
export interface CmsNavLinkProps extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
    link: NavLink & {
        index?: number;
    };
    index?: number;
    list?: NavList;
    as?: React.ElementType;
}
/** Enlace del menú: etiqueta en línea (INLINE_NAV_CHANGE) y botón del editor → FOCUS_NAV. */
export declare function CmsNavLink({ link, index, list, as: A, className, ...rest }: CmsNavLinkProps): import("react/jsx-runtime").JSX.Element;
/** Menú completo: `<CmsNav list="header" className="menu" linkClassName="menu-link" />`. */
export declare function CmsNav({ list, as: Tag, linkClassName, renderLink, ...rest }: Rest & {
    list?: NavList;
    as?: React.ElementType;
    linkClassName?: string;
    renderLink?: (link: NavLink & {
        index: number;
    }) => React.ReactNode;
}): import("react/jsx-runtime").JSX.Element | null;
/** Texto plano de la navegación (`headerCtaText`) o del banner (`promo` → `promoBanner.<f>`). */
export declare function CmsNavText({ f, promo, as: Tag, fallback, className, ...rest }: Rest & {
    f: string;
    promo?: boolean;
    as?: React.ElementType;
    fallback?: string;
}): import("react/jsx-runtime").JSX.Element | null;
export {};
