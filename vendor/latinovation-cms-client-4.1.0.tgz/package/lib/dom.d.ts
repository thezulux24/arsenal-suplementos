import type { LivePreviewBridge, NavChangeTarget, SectionTarget } from './live.js';
/**
 * Runtime del lienzo, independiente del framework: todo se decide por el marcado §8.1.
 * Lo usa el provider de React y sirve igual para sitios sin React (`createBuilderRuntime`).
 *
 *  - asigna `data-el-id` deterministas (`<clave>::div.0>h2.1`, como el renderer del CMS) a los
 *    elementos que no traen uno explícito, y envía SECTION_DOM_TREE al portal;
 *  - clic: SELECT_SECTION + SELECT_ELEMENT; imagen/galería/richtext/enlace/select… → FOCUS_FIELD;
 *    ítems → FOCUS_COLLECTION_ITEM; globales → FOCUS_GLOBAL; navegación → FOCUS_NAV;
 *  - edición en línea: al salir de un `[contenteditable]` marcado envía INLINE_*_CHANGE;
 *  - Ctrl/Cmd+Z, Ctrl/Cmd+Shift+Z / Ctrl+Y → HISTORY; arrastre de secciones → REORDER_DROP;
 *  - etiqueta flotante "Cambiar imagen" al pasar sobre imágenes editables.
 */
export interface SelectedElement {
    sectionId: string;
    sectionKey: string;
    elementId: string;
    parentElementId?: string | null;
    tagName: string;
    label: string;
    textPreview: string;
    computedBg: string;
    computedColor: string;
}
export interface DomTreeEntry {
    elementId: string;
    tag: string;
    label: string;
    textPreview: string;
    depth: number;
}
/**
 * Etiqueta los elementos de cada sección. En el editor, todas; en el sitio público solo las
 * que llevan `data-cms-styled` (tienen `_elementStyles`). Devuelve el árbol por sección.
 */
export declare function tagSectionElements(root: ParentNode, { isBuilder, maxPerSection, maxDepth }?: {
    isBuilder?: boolean | undefined;
    maxPerSection?: number | undefined;
    maxDepth?: number | undefined;
}): Record<string, DomTreeEntry[]>;
export declare function describeElement(el: HTMLElement): SelectedElement | null;
/** Elemento a seleccionar al hacer clic: si el texto está dentro de una "caja" con fondo, la caja. */
export declare function resolveSelectableElement(target: Element): HTMLElement | null;
export type LocalChange = {
    kind: 'field';
    section: SectionTarget;
    path: string;
    value: unknown;
} | {
    kind: 'global';
    fieldKey: string;
    value: unknown;
} | {
    kind: 'nav';
    target: NavChangeTarget;
    value: unknown;
} | {
    kind: 'item';
    collection: string;
    itemId: string;
    fieldKey: string;
    value: unknown;
};
export interface BuilderRuntimeOptions {
    bridge: LivePreviewBridge;
    /** Raíz a observar (por defecto `document`). */
    root?: Document | HTMLElement;
    /** Cambio confirmado en línea, para aplicarlo localmente antes del eco del portal. */
    onLocalChange?: (change: LocalChange) => void;
    onSelectSection?: (sectionKey: string, sectionId: string) => void;
    onSelectElement?: (sel: SelectedElement | null) => void;
    /** Etiquetas de la insignia flotante por tipo. */
    labels?: Partial<Record<string, string>>;
}
export interface BuilderRuntime {
    /** Vuelve a etiquetar y envía SECTION_DOM_TREE. */
    retag(): void;
    selectSection(sectionKey: string): void;
    /** Selecciona y resalta `[data-el-id]` (CMS_SELECT_DOM_ELEMENT). */
    selectElement(elementId: string | null, notify?: boolean): SelectedElement | null;
    destroy(): void;
}
/** Lee el texto editado: sin espacios duros; en una línea salvo `data-cms-multiline`. */
export declare function readEditableText(el: HTMLElement): string;
export declare function createBuilderRuntime(opts: BuilderRuntimeOptions): BuilderRuntime;
