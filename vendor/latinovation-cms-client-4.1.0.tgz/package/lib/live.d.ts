import type { CollectionDefinition, CollectionItem, DeliveryPayload, SectionData, SectionRow } from './types.js';
import { type ArrayOp } from './paths.js';
/**
 * Protocolo de vista previa en vivo entre el portal (/portal) y el sitio dentro del iframe
 * (contrato 2.7, documentado en docs/LIVE-PREVIEW.md).
 *
 *   portal → sitio : CMS_LIVE_PREVIEW_STATE, CMS_SCROLL_TO_SECTION, CMS_HOVER_SECTION, CMS_SELECT_DOM_ELEMENT
 *   sitio  → portal: CMS_CANVAS_ACTION { action, ... }
 */
export declare const CMS_MESSAGES: {
    readonly LIVE_STATE: "CMS_LIVE_PREVIEW_STATE";
    readonly SCROLL_TO_SECTION: "CMS_SCROLL_TO_SECTION";
    readonly HOVER_SECTION: "CMS_HOVER_SECTION";
    readonly SELECT_DOM_ELEMENT: "CMS_SELECT_DOM_ELEMENT";
    readonly CANVAS_ACTION: "CMS_CANVAS_ACTION";
};
/** Acciones que el sitio puede enviar al portal (las que el portal entiende hoy). */
export type CanvasAction = 'SELECT_SECTION' | 'SELECT_ELEMENT' | 'INLINE_FIELD_CHANGE' | 'INLINE_WIDGET_CHANGE' | 'INLINE_ELEMENT_STYLE_CHANGE' | 'INLINE_GLOBAL_CHANGE' | 'INLINE_NAV_CHANGE' | 'INLINE_COLLECTION_ITEM_CHANGE' | 'DELETE_WIDGET' | 'MOVE_SECTION' | 'REORDER_DROP' | 'DUPLICATE_SECTION' | 'DELETE_SECTION' | 'OPEN_ADD_BLOCK_MODAL' | 'OPEN_COLLECTION_MANAGER' | 'OPEN_AI_AGENT_FOR_ELEMENT' | 'SECTION_DOM_TREE' | 'HISTORY' | 'FOCUS_FIELD' | 'ARRAY_ITEM_ACTION' | 'FOCUS_COLLECTION_ITEM' | 'CREATE_COLLECTION_ITEM' | 'FOCUS_GLOBAL' | 'FOCUS_NAV' | 'SECTION_STYLE_CHANGE' | 'COMPOSER_ACTION';
export interface LivePreviewStateMessage {
    type: 'CMS_LIVE_PREVIEW_STATE';
    /** Secciones de la página activa en el editor (con draftData). */
    sectionsList?: SectionRow[];
    globalData?: Record<string, any>;
    navigationConfig?: Record<string, any>;
    collections?: Record<string, CollectionItem[]>;
    /** true: las listas de colecciones reemplazan a las actuales aunque vengan vacías. */
    collectionsAuthoritative?: boolean;
    collectionDefinitions?: Record<string, CollectionDefinition>;
    selectedSectionKey?: string;
    /** Slug de la página que se está editando (si el portal lo envía). */
    pageSlug?: string;
    focusCategory?: string;
}
export interface PreviewParams {
    preview: boolean;
    builder: boolean;
    previewToken: string;
}
/** Lee `?preview=1&builder=1&previewToken=…` de la URL. */
export declare function readPreviewParams(search?: string): PreviewParams;
/**
 * Fusiona el estado en vivo del portal en el payload (borradores sin guardar se ven al instante).
 * Las secciones reemplazan las de la página que contiene esas claves, o la página activa.
 */
export declare function applyLiveState(prev: DeliveryPayload, msg: LivePreviewStateMessage, activePageSlug?: string): DeliveryPayload;
export interface LivePreviewBridgeOptions {
    /** URL del CMS/portal (su origen es el único aceptado). Por defecto https://webproai.tech. */
    cmsUrl?: string;
    /** Orígenes adicionales permitidos (ej. http://localhost:3005 en desarrollo). */
    allowedOrigins?: string[];
    onState?: (msg: LivePreviewStateMessage) => void;
    /** Por defecto hace scroll a `#cms-section-<key>` o `[data-section-key=<key>]`. */
    onScrollTo?: (sectionKey: string) => void;
    /** Por defecto marca la sección con `data-cms-hover`. */
    onHover?: (sectionKey: string) => void;
    /** CMS_SELECT_DOM_ELEMENT: el portal pide resaltar `[data-el-id]`. */
    onSelectElement?: (elementId: string, msg: Record<string, any>) => void;
    /** Cualquier mensaje válido del portal (después de los manejadores propios). */
    onMessage?: (msg: Record<string, any>) => void;
    /** Ventana del sitio (por defecto `window`). */
    win?: Window;
}
export interface LivePreviewBridge {
    /** true si el sitio está dentro de un iframe (modo editor). */
    embedded: boolean;
    post(action: CanvasAction, payload?: Record<string, unknown>): void;
    selectSection(sectionKey: string, sectionId?: string): void;
    commitField(sectionKey: string, sectionId: string, fieldKey: string, value: unknown): void;
    commitWidgetField(sectionKey: string, sectionId: string, widgetIndex: number, fieldKey: string, value: unknown): void;
    commitGlobal(fieldKey: string, value: unknown): void;
    commitCollectionItem(collectionSlug: string, itemId: string, fieldKey: string, value: unknown): void;
    /** INLINE_NAV_CHANGE: enlace (`linkIndex` + `fieldKey`; `navList: 'footerLinks'` para el pie), `promoField` o campo plano. */
    commitNav(target: NavChangeTarget, value: unknown): void;
    focusField(sectionKey: string, sectionId: string, fieldPath: string, fieldType?: string): void;
    arrayItemAction(sectionKey: string, sectionId: string, fieldPath: string, index: number, op: ArrayOp): void;
    focusCollectionItem(collectionSlug: string, itemId: string, fieldKey?: string): void;
    createCollectionItem(collectionSlug: string, category?: string): void;
    focusGlobal(fieldKey: string): void;
    focusNav(linkIndex?: number, navList?: 'headerLinks' | 'footerLinks'): void;
    sectionStyleChange(sectionKey: string, sectionId: string, stylePatch: Record<string, unknown>): void;
    elementStyleChange(sectionKey: string, sectionId: string, elementId: string, stylePatch: Record<string, unknown> | null): void;
    openAddBlock(afterSectionId?: string): void;
    moveSection(sectionId: string, direction: 'UP' | 'DOWN'): void;
    reorderDrop(sourceSectionId: string, targetSectionId: string): void;
    duplicateSection(sectionId: string): void;
    deleteSection(sectionId: string): void;
    history(direction: 'undo' | 'redo'): void;
    destroy(): void;
}
export interface NavChangeTarget {
    linkIndex?: number;
    navList?: 'headerLinks' | 'footerLinks';
    promoField?: string;
    fieldKey?: string;
}
export declare function findSectionElement(doc: Document, key: string): HTMLElement | null;
/**
 * Conecta el sitio con el portal. Solo acepta mensajes de `window.parent` con origen permitido
 * y envía siempre al origen del CMS (nunca `*`).
 */
export declare function createLivePreviewBridge(opts?: LivePreviewBridgeOptions): LivePreviewBridge;
export interface SectionTarget {
    id?: string;
    key: string;
}
/** Reemplaza `data` de la sección (por id; si no hay id, por clave) en la página indicada. */
export declare function updateSectionData(p: DeliveryPayload, pageSlug: string, section: SectionTarget, update: (data: SectionData) => SectionData): DeliveryPayload;
/** `INLINE_FIELD_CHANGE` local: asigna `path` (con puntos) sin perder hermanos. */
export declare function applyFieldChange(p: DeliveryPayload, pageSlug: string, section: SectionTarget, path: string, value: unknown): DeliveryPayload;
/** `ARRAY_ITEM_ACTION` local (excepto `add`, que espera los valores por defecto del portal). */
export declare function applyArrayChange(p: DeliveryPayload, pageSlug: string, section: SectionTarget, path: string, index: number, op: ArrayOp): DeliveryPayload;
/** `INLINE_ELEMENT_STYLE_CHANGE` local (`null` borra el estilo del elemento). */
export declare function applyElementStyleChange(p: DeliveryPayload, pageSlug: string, section: SectionTarget, elementId: string, patch: Record<string, unknown> | null): DeliveryPayload;
/** `SECTION_STYLE_CHANGE` local: fusiona en `_style`. */
export declare function applySectionStyleChange(p: DeliveryPayload, pageSlug: string, section: SectionTarget, patch: Record<string, unknown>): DeliveryPayload;
/** `INLINE_GLOBAL_CHANGE` local (acepta ruta con puntos). */
export declare function applyGlobalChange(p: DeliveryPayload, fieldKey: string, value: unknown): DeliveryPayload;
/** `INLINE_NAV_CHANGE` local. */
export declare function applyNavChange(p: DeliveryPayload, target: NavChangeTarget, value: unknown): DeliveryPayload;
/** `INLINE_COLLECTION_ITEM_CHANGE` local. */
export declare function applyCollectionItemChange(p: DeliveryPayload, collectionSlug: string, itemId: string, fieldKey: string, value: unknown): DeliveryPayload;
