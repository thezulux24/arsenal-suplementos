/**
 * Design System v2 (docs/EDITING-V4.1.md §A) → variables CSS `--cms-*` y enlaces de fuentes.
 *
 * `designSystemToCssVars(ds)` y `designSystemFontLinks(ds)` tienen la misma firma que la
 * función de referencia prevista en `shared/`; aceptan v2 (`version: 2`, grupos `colors`,
 * `typography`, `shape`…) y los campos planos v1 (`primaryColor`, `headingFont`, `borderRadius`…).
 * Puedes pasar `globalData` completo: si trae `designSystem`, se combina con sus campos planos.
 */
export type DesignSystemInput = Record<string, any> | null | undefined;
export declare function fontStack(family: string): string;
/** Combina `globalData` (campos planos v1) con `globalData.designSystem` (v1 plano o v2). */
export declare function normalizeDesignSystem(input: DesignSystemInput): Record<string, any>;
/** Variables `--cms-*` (todas, con valores por defecto) para `:root` o la raíz del sitio. */
export declare function designSystemToCssVars(ds: DesignSystemInput): Record<string, string>;
/** Texto CSS `selector{--cms-…}` listo para un `<style>`. */
export declare function designSystemToCss(ds: DesignSystemInput, selector?: string): string;
/** URLs de hojas de estilo de Google Fonts para las fuentes `source: google` (sin duplicados). */
export declare function designSystemFontLinks(ds: DesignSystemInput): string[];
/** Reglas `@font-face` para `typography.customFonts` y fuentes `source: custom` con `url`. */
export declare function designSystemFontFaces(ds: DesignSystemInput): string;
/** CSS libre del cliente (`designSystem.globalCss`); sanearlo con `sanitizeCss` antes de inyectar. */
export declare function designSystemGlobalCss(ds: DesignSystemInput): string;
