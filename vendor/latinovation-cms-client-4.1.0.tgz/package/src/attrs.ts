import type { FieldType } from './types.js';

/**
 * Atributos de marcado del contrato §8.1 (docs/LIVE-PREVIEW.md). Se emiten siempre — también en
 * producción — para que el portal y la auditoría de editabilidad los lean del HTML. La
 * interactividad (contentEditable, toolbars, listeners) solo existe en modo editor.
 */

export type CmsAttrs = Record<string, string | undefined>;

/** Tipo de `data-cms-type`. Además de los del catálogo, el SDK usa `array` (repetidor) e `item` (elemento de un repetidor). */
export type MarkupType = FieldType | 'item';

export interface EditAttrsInput {
  /** Ruta del campo (`headline`, `items.2.title`). */
  field?: string;
  type?: MarkupType | string;
  /** Ítem de colección: `{ collection, id }` o `"coleccion:itemId"`. */
  item?: { collection: string; id: string } | string;
  /** Campo de `globalData`. */
  global?: string;
  /** Navegación: índice de `headerLinks` (`2`), `footer.<i>`, `promoBanner.<campo>` o un campo plano (`headerCtaText`). */
  nav?: number | string;
  /** Id estable para estilos por elemento (`_elementStyles`). */
  elId?: string;
}

/** `{ 'data-cms-field': 'items.2.title', 'data-cms-type': 'text', … }` sin claves vacías. */
export function editAttrs(input: EditAttrsInput): CmsAttrs {
  const out: CmsAttrs = {};
  if (input.field) out['data-cms-field'] = input.field;
  if (input.type) out['data-cms-type'] = String(input.type);
  if (input.item) out['data-cms-item'] = typeof input.item === 'string' ? input.item : `${input.item.collection}:${input.item.id}`;
  if (input.global) out['data-cms-global'] = input.global;
  if (input.nav !== undefined && input.nav !== null && input.nav !== '') out['data-cms-nav'] = String(input.nav);
  if (input.elId) out['data-el-id'] = input.elId;
  return out;
}

export interface SectionAttrsInput {
  id: string;
  key: string;
  block?: string | null;
}

/** Raíz de sección: `data-section-key`, `data-section-id`, `data-cms-block` e `id="cms-section-<key>"`. */
export function sectionAttrs(s: SectionAttrsInput, { withId = true } = {}): CmsAttrs {
  const out: CmsAttrs = {
    'data-section-key': s.key,
    'data-section-id': s.id,
  };
  if (withId) out.id = sectionDomId(s.key);
  if (s.block) out['data-cms-block'] = s.block;
  return out;
}

export function sectionDomId(key: string): string {
  return `cms-section-${key}`;
}

/** Id de elemento estable derivado de la sección y del campo: `hero::headline`. */
export function elementId(sectionKey: string, name: string): string {
  return `${sectionKey}::${name}`;
}

/** Interpreta `data-cms-item="coleccion:itemId"`. */
export function parseItemAttr(v: string | null | undefined): { collection: string; id: string } | null {
  if (!v) return null;
  const i = v.indexOf(':');
  if (i <= 0) return null;
  return { collection: v.slice(0, i), id: v.slice(i + 1) };
}

export type NavTarget =
  | { kind: 'link'; list: 'header' | 'footer'; index: number }
  | { kind: 'promo'; field: string }
  | { kind: 'field'; field: string };

/** Interpreta `data-cms-nav`: `"2"`, `"footer.1"`, `"promoBanner.title"`, `"headerCtaText"`. */
export function parseNavAttr(v: string | null | undefined): NavTarget | null {
  if (v === null || v === undefined || v === '') return null;
  if (/^\d+$/.test(v)) return { kind: 'link', list: 'header', index: Number(v) };
  const m = v.match(/^(header|footer)\.(\d+)$/);
  if (m) return { kind: 'link', list: m[1] as 'header' | 'footer', index: Number(m[2]) };
  const p = v.match(/^promoBanner\.(.+)$/);
  if (p) return { kind: 'promo', field: p[1] };
  return { kind: 'field', field: v };
}

/** Tipos que se editan en línea (contentEditable) en vez de abrir el inspector. */
export const INLINE_TYPES = new Set(['text', 'textarea']);
