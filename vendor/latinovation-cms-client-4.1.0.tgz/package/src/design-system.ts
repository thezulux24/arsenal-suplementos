/**
 * Design System v2 (docs/EDITING-V4.1.md §A) → variables CSS `--cms-*` y enlaces de fuentes.
 *
 * `designSystemToCssVars(ds)` y `designSystemFontLinks(ds)` tienen la misma firma que la
 * función de referencia prevista en `shared/`; aceptan v2 (`version: 2`, grupos `colors`,
 * `typography`, `shape`…) y los campos planos v1 (`primaryColor`, `headingFont`, `borderRadius`…).
 * Puedes pasar `globalData` completo: si trae `designSystem`, se combina con sus campos planos.
 */

export type DesignSystemInput = Record<string, any> | null | undefined;

const SYSTEM_FONTS: Record<string, string> = {
  serif: 'Georgia, "Times New Roman", serif',
  sans: 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif',
  'sans-serif': 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif',
  'system-ui': 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif',
  mono: 'ui-monospace, "SFMono-Regular", Menlo, monospace',
  monospace: 'ui-monospace, "SFMono-Regular", Menlo, monospace',
};

const SERIF_HINT = /serif|fraunces|playfair|newsreader|garamond|lora|cormorant|baskerville|merriweather|marcellus|instrument serif|crimson|spectral|literata|bodoni|young serif|dm serif/i;

function isObj(v: unknown): v is Record<string, any> {
  return Boolean(v) && typeof v === 'object' && !Array.isArray(v);
}

function clean(v: unknown): string {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[{};<>]/g, '').replace(/[\n\r]+/g, ' ').trim();
}

function px(v: unknown, fallback: string): string {
  if (v === null || v === undefined || v === '') return fallback;
  if (typeof v === 'number') return Number.isFinite(v) ? `${v}px` : fallback;
  const s = clean(v);
  if (/^-?\d+(\.\d+)?$/.test(s)) return `${s}px`;
  return s || fallback;
}

function slug(s: string): string {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

type FontSpec = { family: string; source: 'google' | 'custom' | 'system'; weights: number[]; url?: string };

function fontSpec(v: unknown, fallback: string): FontSpec {
  if (isObj(v)) {
    const family = clean(v.family) || fallback;
    const source = v.source === 'custom' || v.source === 'system' || v.source === 'google' ? v.source : SYSTEM_FONTS[family.toLowerCase()] ? 'system' : 'google';
    const weights = Array.isArray(v.weights) ? v.weights.map(Number).filter((n: number) => n >= 100 && n <= 1000) : [];
    return { family, source, weights, url: clean(v.url) || undefined };
  }
  const family = clean(v) || fallback;
  return { family, source: SYSTEM_FONTS[family.toLowerCase()] ? 'system' : 'google', weights: [] };
}

export function fontStack(family: string): string {
  const f = clean(family);
  if (!f) return SYSTEM_FONTS.sans;
  if (SYSTEM_FONTS[f.toLowerCase()]) return SYSTEM_FONTS[f.toLowerCase()];
  const generic = SERIF_HINT.test(f) && !/sans/i.test(f) ? 'Georgia, serif' : 'ui-sans-serif, system-ui, sans-serif';
  return `"${f.replace(/"/g, '')}", ${generic}`;
}

/** Combina `globalData` (campos planos v1) con `globalData.designSystem` (v1 plano o v2). */
export function normalizeDesignSystem(input: DesignSystemInput): Record<string, any> {
  if (!isObj(input)) return {};
  const nested = isObj(input.designSystem) ? input.designSystem : null;
  return nested ? { ...input, ...nested } : { ...input };
}

/** Variables `--cms-*` (todas, con valores por defecto) para `:root` o la raíz del sitio. */
export function designSystemToCssVars(ds: DesignSystemInput): Record<string, string> {
  const d = normalizeDesignSystem(ds);
  const c = isObj(d.colors) ? d.colors : {};
  const t = isObj(d.typography) ? d.typography : {};
  const sh = isObj(d.shape) ? d.shape : {};
  const sd = isObj(d.shadow) ? d.shadow : {};
  const sp = isObj(d.spacing) ? d.spacing : {};
  const b = isObj(d.buttons) ? d.buttons : {};
  const m = isObj(d.motion) ? d.motion : {};

  const pick = (...vals: unknown[]) => {
    for (const v of vals) {
      const s = clean(v);
      if (s) return s;
    }
    return '';
  };
  const bg = pick(c.background, d.backgroundColor) || '#FFFFFF';
  const text = pick(c.text, d.textColor) || '#15171C';
  const primary = pick(c.primary, d.primaryColor) || text;
  const secondary = pick(c.secondary, d.secondaryColor) || primary;
  const accent = pick(c.accent, d.accentColor) || secondary;

  const vars: Record<string, string> = {
    '--cms-bg': bg,
    '--cms-surface': pick(c.surface, d.surfaceColor, d.cardBg) || bg,
    '--cms-surface-alt': pick(c.surfaceAlt, d.altBackgroundColor) || `color-mix(in srgb, ${text} 5%, ${bg})`,
    '--cms-text': text,
    '--cms-muted': pick(c.muted, d.mutedTextColor) || `color-mix(in srgb, ${text} 70%, ${bg})`,
    '--cms-border': pick(c.border, d.borderColor) || `color-mix(in srgb, ${text} 14%, ${bg})`,
    '--cms-primary': primary,
    '--cms-primary-text': pick(c.primaryText, d.primaryTextColor) || '#FFFFFF',
    '--cms-secondary': secondary,
    '--cms-secondary-text': pick(c.secondaryText, d.secondaryTextColor) || '#FFFFFF',
    '--cms-accent': accent,
    '--cms-success': pick(c.success) || '#1E7A4C',
    '--cms-danger': pick(c.danger) || '#B42318',
  };
  if (Array.isArray(c.custom)) {
    for (const col of c.custom) {
      const name = slug(col?.name);
      const value = clean(col?.value);
      if (name && value) vars[`--cms-color-${name}`] = value;
    }
  }

  const heading = fontSpec(t.headingFont ?? d.headingFont, 'sans');
  const body = fontSpec(t.bodyFont ?? d.bodyFont, 'sans');
  const serifHeading = SERIF_HINT.test(heading.family) && !/sans/i.test(heading.family);
  const headingCase = ['none', 'uppercase', 'capitalize', 'lowercase'].includes(t.headingCase) ? t.headingCase : 'none';
  const tracking = t.headingTracking;
  vars['--cms-font-heading'] = fontStack(heading.family);
  vars['--cms-font-body'] = fontStack(body.family);
  vars['--cms-text-base'] = px(t.baseSize, '16px');
  vars['--cms-scale'] = String(Number(t.scaleRatio) > 1 ? Number(t.scaleRatio) : 1.25);
  vars['--cms-heading-weight'] = String(Number(t.headingWeight ?? d.headingWeight) || (serifHeading ? 400 : 600));
  vars['--cms-body-weight'] = String(Number(t.bodyWeight) || 400);
  vars['--cms-heading-case'] = headingCase;
  vars['--cms-heading-tracking'] = typeof tracking === 'number' ? `${tracking}em` : clean(tracking) || (serifHeading ? '-0.01em' : '-0.02em');
  vars['--cms-line-height'] = String(Number(t.bodyLineHeight) || 1.55);

  const legacyRadius = px(d.borderRadius, '6px');
  vars['--cms-radius-sm'] = px(sh.radiusSm, `calc(${legacyRadius} / 2)`);
  vars['--cms-radius-md'] = px(sh.radiusMd, legacyRadius);
  vars['--cms-radius-lg'] = px(sh.radiusLg, `calc(${legacyRadius} * 2)`);
  vars['--cms-radius-full'] = px(sh.radiusFull, '999px');
  vars['--cms-border-width'] = px(sh.borderWidth, '1px');

  vars['--cms-shadow-sm'] = clean(sd.sm) || '0 1px 2px rgb(0 0 0 / .06)';
  vars['--cms-shadow-md'] = clean(sd.md) || '0 6px 20px -8px rgb(0 0 0 / .2)';
  vars['--cms-shadow-lg'] = clean(sd.lg) || '0 24px 48px -16px rgb(0 0 0 / .28)';

  const density = d.density === 'compact' ? 0.8 : d.density === 'airy' ? 1.2 : 1;
  vars['--cms-section-y'] = px(sp.sectionY, `${Math.round(112 * density)}px`);
  vars['--cms-section-y-mobile'] = px(sp.sectionYMobile, `${Math.round(72 * density)}px`);
  vars['--cms-gutter'] = px(sp.gutter, '24px');
  vars['--cms-max-width'] = px(sp.maxWidth, '1240px');

  const shape = String(b.shape || d.buttonShape || '').toLowerCase();
  vars['--cms-btn-radius'] = shape === 'pill' ? 'var(--cms-radius-full)' : shape === 'square' ? '0px' : 'var(--cms-radius-md)';
  vars['--cms-btn-case'] = b.case === 'uppercase' ? 'uppercase' : 'none';
  vars['--cms-btn-weight'] = String(Number(b.weight) || 600);
  vars['--cms-btn-py'] = px(b.paddingY, '12px');
  vars['--cms-btn-px'] = px(b.paddingX, '22px');

  const level = String(m.level || 'subtle');
  vars['--cms-duration'] = level === 'none' ? '0ms' : `${Number(m.durationMs) || (level === 'expressive' ? 320 : 220)}ms`;
  return vars;
}

/** Texto CSS `selector{--cms-…}` listo para un `<style>`. */
export function designSystemToCss(ds: DesignSystemInput, selector = ':root'): string {
  const vars = designSystemToCssVars(ds);
  return `${selector}{${Object.entries(vars).map(([k, v]) => `${k}:${v}`).join(';')}}`;
}

/** URLs de hojas de estilo de Google Fonts para las fuentes `source: google` (sin duplicados). */
export function designSystemFontLinks(ds: DesignSystemInput): string[] {
  const d = normalizeDesignSystem(ds);
  const t = isObj(d.typography) ? d.typography : {};
  const specs = [fontSpec(t.headingFont ?? d.headingFont, ''), fontSpec(t.bodyFont ?? d.bodyFont, '')].filter((f) => f.family && f.source === 'google');
  const byFamily = new Map<string, Set<number>>();
  for (const f of specs) {
    const set = byFamily.get(f.family) || new Set<number>();
    (f.weights.length ? f.weights : [400, 500, 600, 700]).forEach((w) => set.add(w));
    byFamily.set(f.family, set);
  }
  return Array.from(byFamily.entries()).map(([family, weights]) => {
    const w = Array.from(weights).sort((a, b) => a - b).join(';');
    return `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family).replace(/%20/g, '+')}:wght@${w}&display=swap`;
  });
}

/** Reglas `@font-face` para `typography.customFonts` y fuentes `source: custom` con `url`. */
export function designSystemFontFaces(ds: DesignSystemInput): string {
  const d = normalizeDesignSystem(ds);
  const t = isObj(d.typography) ? d.typography : {};
  const faces: Array<{ family: string; url: string; weight?: unknown; style?: unknown }> = [];
  if (Array.isArray(t.customFonts)) faces.push(...t.customFonts);
  for (const f of [t.headingFont, t.bodyFont]) if (isObj(f) && f.source === 'custom' && f.url) faces.push({ family: f.family, url: f.url, weight: f.weights?.[0] });
  return faces
    .filter((f) => clean(f.family) && /^https?:\/\/|^\//.test(String(f.url || '')))
    .map((f) => {
      const url = String(f.url).replace(/["\\\n\r]/g, '');
      const fmt = /\.woff2(\?|$)/i.test(url) ? 'woff2' : /\.woff(\?|$)/i.test(url) ? 'woff' : /\.ttf(\?|$)/i.test(url) ? 'truetype' : /\.otf(\?|$)/i.test(url) ? 'opentype' : '';
      const weight = Number(f.weight) || 400;
      const style = f.style === 'italic' ? 'italic' : 'normal';
      return `@font-face{font-family:"${clean(f.family).replace(/"/g, '')}";src:url("${url}")${fmt ? ` format("${fmt}")` : ''};font-weight:${weight};font-style:${style};font-display:swap}`;
    })
    .join('\n');
}

/** CSS libre del cliente (`designSystem.globalCss`); sanearlo con `sanitizeCss` antes de inyectar. */
export function designSystemGlobalCss(ds: DesignSystemInput): string {
  const d = normalizeDesignSystem(ds);
  return typeof d.globalCss === 'string' ? d.globalCss : '';
}
