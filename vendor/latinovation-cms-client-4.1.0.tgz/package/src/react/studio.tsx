'use client';

import React from 'react';
import { getSections } from '../delivery.js';
import { describeElement } from '../dom.js';
import { useCms } from './context.js';

export function parseColorToHexAndAlpha(colorStr: string): { hex: string; alpha: number } {
  if (!colorStr || colorStr === 'transparent' || colorStr === 'rgba(0, 0, 0, 0)') return { hex: '#171412', alpha: 0 };
  const s = colorStr.trim();
  if (s.startsWith('#')) {
    if (s.length === 4) return { hex: `#${s[1]}${s[1]}${s[2]}${s[2]}${s[3]}${s[3]}`, alpha: 100 };
    return { hex: s.slice(0, 7), alpha: 100 };
  }
  const m = s.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/i);
  if (m) {
    const h = (n: string) => Math.min(255, parseInt(n, 10)).toString(16).padStart(2, '0');
    const a = m[4] !== undefined ? Math.round(parseFloat(m[4]) * 100) : 100;
    return { hex: `#${h(m[1])}${h(m[2])}${h(m[3])}`, alpha: Math.max(0, Math.min(100, a)) };
  }
  return { hex: '#171412', alpha: 85 };
}

export function hexAndAlphaToRgba(hex: string, alphaPercent: number): string {
  const clean = (hex || '#171412').replace('#', '');
  const r = parseInt(clean.slice(0, 2) || '17', 16) || 23;
  const g = parseInt(clean.slice(2, 4) || '14', 16) || 20;
  const b = parseInt(clean.slice(4, 6) || '12', 16) || 18;
  const a = Math.max(0, Math.min(100, alphaPercent)) / 100;
  if (a === 0) return 'transparent';
  if (a === 1) return `#${clean.slice(0, 6)}`;
  return `rgba(${r}, ${g}, ${b}, ${Number(a.toFixed(2))})`;
}

const POSITIONS = [
  { id: 'top-left', icon: '↖', title: 'Arriba a la izquierda' },
  { id: 'top-right', icon: '↗', title: 'Arriba a la derecha' },
  { id: 'center', icon: '⊕', title: 'Centro' },
  { id: 'bottom-left', icon: '↙', title: 'Abajo a la izquierda' },
  { id: 'bottom-right', icon: '↘', title: 'Abajo a la derecha' },
];

/**
 * Barra flotante del elemento seleccionado (como ElementStudioToolbar del CMS): fondo y opacidad,
 * color de texto, posición, mover libremente, caja padre, Art y restablecer.
 */
export function ElementStudio() {
  const cms = useCms();
  const sel = cms.selectedElement;
  if (!cms.isBuilder || !sel) return null;
  const sec = getSections(cms.payload, cms.pageSlug, { includeHidden: true }).find((s) => s.id === sel.sectionId || s.key === sel.sectionKey);
  const st = (sec?.data?._elementStyles?.[sel.elementId] || {}) as Record<string, any>;
  const { hex: bgHex, alpha: bgAlpha } = parseColorToHexAndAlpha(st.backgroundColor || sel.computedBg || '#171412');
  const { hex: textHex } = parseColorToHexAndAlpha(st.textColor || sel.computedColor || '#F5F2EB');
  const offsetX = Number(st.offsetX || 0);
  const offsetY = Number(st.offsetY || 0);
  const target = { key: sel.sectionKey, id: sel.sectionId };
  const commit = (patch: Record<string, unknown> | null) => cms.actions.elementStyle(target, sel.elementId, patch);

  const selectParent = () => {
    if (!sel.parentElementId) return;
    const node = document.querySelector(`[data-el-id="${sel.parentElementId.replace(/["\\]/g, '\\$&')}"]`) as HTMLElement | null;
    const next = node ? describeElement(node) : null;
    if (next) {
      document.querySelectorAll('[data-cms-el-selected]').forEach((el) => el.removeAttribute('data-cms-el-selected'));
      node!.setAttribute('data-cms-el-selected', 'true');
      cms.setSelectedElement(next);
      cms.post('SELECT_ELEMENT', next as unknown as Record<string, unknown>);
    }
  };

  const startMove = (e: React.MouseEvent) => {
    e.preventDefault();
    const sx = e.clientX;
    const sy = e.clientY;
    const onMove = (mv: MouseEvent) => commit({ offsetX: Math.round(offsetX + (mv.clientX - sx)), offsetY: Math.round(offsetY + (mv.clientY - sy)) });
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  return (
    <div className="cms-ui cms-ui-studio" role="toolbar" aria-label="Estilo del elemento">
      <div className="cms-ui-group">
        <span className="cms-ui-title" title={sel.label}>
          {sel.label}
        </span>
        {sel.parentElementId ? (
          <button type="button" onClick={selectParent} title="Seleccionar la caja que lo contiene">
            ↑ Caja padre
          </button>
        ) : null}
      </div>
      <div className="cms-ui-group">
        <span className="cms-ui-label">Fondo</span>
        <input type="color" aria-label="Color de fondo" value={bgHex} onChange={(e) => commit({ backgroundColor: hexAndAlphaToRgba(e.target.value, bgAlpha === 0 ? 85 : bgAlpha) })} />
        <input type="range" min={0} max={100} aria-label="Opacidad del fondo" value={bgAlpha} onChange={(e) => commit({ backgroundColor: hexAndAlphaToRgba(bgHex, Number(e.target.value)) })} />
        <span className="cms-ui-label">{bgAlpha}%</span>
      </div>
      <div className="cms-ui-group">
        <span className="cms-ui-label">Texto</span>
        <input type="color" aria-label="Color del texto" value={textHex} onChange={(e) => commit({ textColor: e.target.value })} />
      </div>
      <div className="cms-ui-group">
        <span className="cms-ui-label">Posición</span>
        {POSITIONS.map((p) => (
          <button key={p.id} type="button" title={p.title} aria-pressed={st.positionPreset === p.id} onClick={() => commit({ positionPreset: p.id, offsetX: 0, offsetY: 0 })}>
            {p.icon}
          </button>
        ))}
        <button type="button" onMouseDown={startMove} title="Mantén presionado y arrastra para mover la caja">
          ✥ Mover ({offsetX},{offsetY})
        </button>
      </div>
      <div className="cms-ui-group">
        <button type="button" data-tone="primary" onClick={() => cms.post('OPEN_AI_AGENT_FOR_ELEMENT', sel as unknown as Record<string, unknown>)}>
          Pedir a Art
        </button>
        <button type="button" onClick={() => commit(null)} title="Quitar los estilos de este elemento">
          Restablecer
        </button>
        <button type="button" onClick={() => cms.setSelectedElement(null)} aria-label="Cerrar">
          ✕
        </button>
      </div>
    </div>
  );
}
