import type { CollectionItem, DeliveryPayload, FieldSchema, SectionData } from './types.js';
import { getSections } from './delivery.js';
import { getBlockSchema, inferFieldType, isImageCompanion, str } from './fields.js';

/**
 * Auditoría de editabilidad (docs/LIVE-PREVIEW.md §8.5): compara cada campo con valor de cada
 * sección visible (y globales, navegación e ítems de colecciones que se muestran) contra el
 * marcado §8.1 del HTML público. Sin dependencias: incluye un tokenizador HTML pequeño.
 */

// ───────────── HTML ─────────────

export interface HtmlMarks {
  /** Por clave de sección: rutas marcadas con `data-cms-field` (fuera de ítems) y su tipo. */
  sections: Record<string, { id?: string; block?: string; fields: Map<string, string> }>;
  /** `data-cms-global`. */
  globals: Set<string>;
  /** `data-cms-nav`. */
  nav: Set<string>;
  /** `coleccion:itemId` → campos marcados. */
  items: Map<string, Set<string>>;
  /** Texto visible normalizado (sin script/style). */
  text: string;
  /** Valores de `src`/`srcset`/`poster`/`href` de imágenes y medios. */
  media: string[];
  /** Total de elementos con `data-el-id` en el HTML del servidor. */
  elementIds: number;
}

const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source', 'track', 'wbr', 'param', 'keygen']);
const RAW = new Set(['script', 'style', 'textarea', 'title', 'noscript', 'template']);

const ENTITIES: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', '#39': "'" };

export function decodeEntities(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+\d*);/gi, (m, e: string) => {
    if (e[0] === '#') {
      const code = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : m;
    }
    return ENTITIES[e.toLowerCase()] ?? m;
  });
}

export function parseAttrs(src: string): Record<string, string> {
  const out: Record<string, string> = {};
  const re = /([^\s=\/>"']+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) out[m[1].toLowerCase()] = decodeEntities(m[2] ?? m[3] ?? m[4] ?? '');
  return out;
}

export function normalizeText(s: string): string {
  return decodeEntities(String(s || ''))
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[ \s]+/g, ' ')
    .trim();
}

/** Recorre el HTML y extrae el marcado §8.1, el texto visible y las URLs de medios. */
export function collectMarks(html: string): HtmlMarks {
  const marks: HtmlMarks = { sections: {}, globals: new Set(), nav: new Set(), items: new Map(), text: '', media: [], elementIds: 0 };
  const stack: Array<{ tag: string; section?: string; item?: string }> = [];
  const texts: string[] = [];
  const re = /<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<!doctype[^>]*>|<\/([a-zA-Z][\w:-]*)\s*>|<([a-zA-Z][\w:-]*)((?:\s+(?:[^\s=\/>"']+)(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?)*)\s*(\/?)>/gi;
  let last = 0;
  let m: RegExpExecArray | null;
  const currentSection = () => {
    for (let i = stack.length - 1; i >= 0; i--) if (stack[i].section) return stack[i].section;
    return undefined;
  };
  while ((m = re.exec(html))) {
    if (m.index > last) texts.push(html.slice(last, m.index));
    last = re.lastIndex;
    const full = m[0];
    if (full.startsWith('<!')) continue;
    if (m[1]) {
      const tag = m[1].toLowerCase();
      for (let i = stack.length - 1; i >= 0; i--) {
        if (stack[i].tag === tag) {
          stack.length = i;
          break;
        }
      }
      continue;
    }
    const tag = m[2].toLowerCase();
    const attrs = parseAttrs(m[3] || '');
    const entry: { tag: string; section?: string; item?: string } = { tag };
    if (attrs['data-section-key'] !== undefined) {
      const key = attrs['data-section-key'];
      entry.section = key;
      const s = (marks.sections[key] ||= { fields: new Map() });
      if (attrs['data-section-id']) s.id = attrs['data-section-id'];
      if (attrs['data-cms-block']) s.block = attrs['data-cms-block'];
    }
    if (attrs['data-el-id']) marks.elementIds++;
    const item = attrs['data-cms-item'] || undefined;
    if (item) entry.item = item;
    const field = attrs['data-cms-field'];
    const type = attrs['data-cms-type'] || '';
    // Un campo es de un ítem solo si el propio elemento lleva data-cms-item (igual que el runtime del lienzo).
    const inItem = item;
    if (inItem) {
      const set = marks.items.get(inItem) || new Set<string>();
      if (field) set.add(field);
      marks.items.set(inItem, set);
    } else if (field && attrs['data-cms-global'] === undefined && attrs['data-cms-nav'] === undefined) {
      const sec = entry.section || currentSection();
      if (sec) (marks.sections[sec] ||= { fields: new Map() }).fields.set(field, type);
    }
    if (attrs['data-cms-global']) marks.globals.add(attrs['data-cms-global']);
    if (attrs['data-cms-nav'] !== undefined && attrs['data-cms-nav'] !== '') marks.nav.add(attrs['data-cms-nav']);
    for (const a of ['src', 'srcset', 'poster', 'data-src']) if (attrs[a]) marks.media.push(attrs[a]);
    if (tag === 'img' && attrs.alt) texts.push(` ${attrs.alt} `);
    if (attrs.style && /url\(/i.test(attrs.style)) marks.media.push(attrs.style);
    const selfClosing = m[4] === '/' || VOID.has(tag);
    if (RAW.has(tag) && !selfClosing) {
      const close = new RegExp(`</${tag}\\s*>`, 'i');
      const rest = html.slice(re.lastIndex);
      const end = rest.search(close);
      const inner = end >= 0 ? rest.slice(0, end) : rest;
      if (tag === 'textarea' || tag === 'title') texts.push(` ${inner} `);
      re.lastIndex += end >= 0 ? end + (rest.slice(end).match(close)?.[0].length || 0) : rest.length;
      last = re.lastIndex;
      continue;
    }
    if (!selfClosing) stack.push(entry);
  }
  if (last < html.length) texts.push(html.slice(last));
  marks.text = normalizeText(texts.join(' '));
  return marks;
}

// ───────────── campos esperados ─────────────

/** Claves de configuración que no son contenido visible (no cuentan en la cobertura). */
export const DEFAULT_IGNORED_KEYS = [
  'anchor',
  'tone',
  'layout',
  'variant',
  'theme',
  'columns',
  'imageSide',
  'align',
  'size',
  'height',
  'width',
  'overlay',
  'sticky',
  'target',
  'newTab',
  'icon',
  'id',
  'slug',
  'key',
  'sku',
  'formName',
  'formId',
  'successMessage',
  'messageTemplate',
  'whatsappNumber',
  'mapQuery',
  'placeholder',
  'options',
  'required',
  'type',
  'redirectTo',
  'notifyEmails',
  'webhookUrl',
  'source',
  'href',
];

const CONTENT_TYPES = new Set(['text', 'textarea', 'richtext', 'image', 'gallery', 'link', 'reference']);

export interface ExpectedField {
  path: string;
  type: string;
  value: string;
  /** Ítems referenciados (`reference`): `coleccion:id`. */
  refs?: string[];
}

function linkHasValue(v: any): boolean {
  return Boolean(v && typeof v === 'object' && (str(v.label).trim() || str(v.href ?? v.url).trim()));
}

function refIndex(p: DeliveryPayload | null | undefined): Map<string, string> {
  const idx = new Map<string, string>();
  for (const [col, items] of Object.entries(p?.collections || {})) {
    for (const it of items || []) {
      if (it.slug) idx.set(String(it.slug), `${col}:${it.id}`);
      if (it.id) idx.set(String(it.id), `${col}:${it.id}`);
    }
  }
  return idx;
}

function referenceTargets(value: string, idx: Map<string, string>): string[] | undefined {
  const parts = value.split(/\s*[,|\n]\s*/).map((s) => s.trim()).filter(Boolean);
  if (!parts.length || parts.some((s) => /\s/.test(s))) return undefined;
  const refs = parts.map((s) => idx.get(s));
  return refs.every(Boolean) ? (refs as string[]) : undefined;
}

/** Campos con valor que una sección debería exponer en el lienzo. */
export function expectedSectionFields(data: SectionData, block: string | null | undefined, p?: DeliveryPayload | null, ignore: string[] = DEFAULT_IGNORED_KEYS): ExpectedField[] {
  const out: ExpectedField[] = [];
  const ignored = new Set(ignore);
  const idx = refIndex(p);
  const schema = getBlockSchema(block);

  const pushText = (path: string, type: string, v: unknown) => {
    const s = str(v).trim();
    if (!s) return;
    const refs = type === 'text' || type === 'textarea' ? referenceTargets(s, idx) : undefined;
    out.push(refs ? { path, type: 'reference', value: s, refs } : { path, type, value: s });
  };

  const walkSchema = (fields: FieldSchema[], obj: any, prefix: string) => {
    for (const f of fields) {
      if (f.group === 'style' || ignored.has(f.key)) continue;
      const path = prefix ? `${prefix}.${f.key}` : f.key;
      const v = obj?.[f.key];
      if (isImageCompanion(f.key, obj || {})) continue;
      if (f.type === 'array') {
        if (Array.isArray(v)) v.forEach((it, i) => (it && typeof it === 'object' ? walkSchema(f.fields || [], it, `${path}.${i}`) : pushText(`${path}.${i}`, 'text', it)));
        continue;
      }
      if (f.type === 'link') {
        if (linkHasValue(v)) out.push({ path, type: 'link', value: str(v.label) || str(v.href) });
        continue;
      }
      if (f.type === 'gallery') {
        if ((Array.isArray(v) && v.length) || str(v).trim()) out.push({ path, type: 'gallery', value: Array.isArray(v) ? `${v.length} imágenes` : str(v) });
        continue;
      }
      if (!CONTENT_TYPES.has(f.type)) continue;
      pushText(path, f.type, v);
    }
  };

  const walkInfer = (obj: any, prefix: string, depth: number) => {
    if (!obj || typeof obj !== 'object' || depth > 6) return;
    for (const [k, v] of Object.entries(obj)) {
      if (k.startsWith('_') || ignored.has(k) || isImageCompanion(k, obj)) continue;
      const path = prefix ? `${prefix}.${k}` : k;
      if (v === null || v === undefined || typeof v === 'boolean' || typeof v === 'number') continue;
      if (Array.isArray(v)) {
        const t = inferFieldType(v, k);
        if (t === 'gallery') {
          out.push({ path, type: 'gallery', value: `${v.length} imágenes` });
          continue;
        }
        v.forEach((it, i) => (it && typeof it === 'object' ? walkInfer(it, `${path}.${i}`, depth + 1) : pushText(`${path}.${i}`, 'text', it)));
        continue;
      }
      if (typeof v === 'object') {
        if ('href' in (v as any) || 'url' in (v as any)) {
          if (linkHasValue(v)) out.push({ path, type: 'link', value: str((v as any).label) || str((v as any).href ?? (v as any).url) });
        } else walkInfer(v, path, depth + 1);
        continue;
      }
      const t = inferFieldType(v, k);
      if (t === 'color') continue;
      pushText(path, t, v);
    }
  };

  if (schema) walkSchema(schema.fields, data, '');
  else walkInfer(data, '', 0);
  return out;
}

// ───────────── cobertura ─────────────

export interface FieldResult extends ExpectedField {
  covered: boolean;
  /** El valor aparece en el HTML pero sin marcado (visible y no editable desde el lienzo). */
  shownUnmarked?: boolean;
}

export interface UnitReport {
  page: string;
  path: string;
  /** Clave de sección, o `[global]`, `[nav]`, `[items:<coleccion>]`. */
  unit: string;
  block?: string | null;
  rendered: boolean;
  total: number;
  covered: number;
  pct: number;
  fields: FieldResult[];
}

export interface AuditPageInput {
  /** Ruta pedida (`/`, `/producto/creatina`). */
  path: string;
  /** Página del CMS que corresponde. */
  pageSlug: string;
  html: string;
  /** Si no se pudo descargar. */
  error?: string;
}

export interface AuditOptions {
  ignore?: string[];
  /** Incluir globales, navegación e ítems (por defecto true). */
  extras?: boolean;
}

export interface AuditReport {
  units: UnitReport[];
  pages: Array<{ path: string; pageSlug: string; error?: string; total: number; covered: number; pct: number }>;
  total: number;
  covered: number;
  pct: number;
}

function pct(c: number, t: number): number {
  return t ? Math.round((c / t) * 1000) / 10 : 100;
}

function fieldCovered(f: ExpectedField, marks: Map<string, string> | undefined, html: HtmlMarks): boolean {
  if (marks) {
    if (marks.has(f.path)) return true;
    if (f.type === 'link' && (marks.has(`${f.path}.label`) || marks.has(`${f.path}.href`))) return true;
    for (const [m, t] of marks) if (t !== 'array' && t !== 'item' && f.path.startsWith(`${m}.`)) return true;
  }
  if (f.type === 'reference' && f.refs?.length) return f.refs.every((r) => html.items.has(r));
  return false;
}

function appearsInText(value: string, html: HtmlMarks): boolean {
  const v = normalizeText(value).slice(0, 60);
  return v.length >= 3 && html.text.includes(v);
}

function appearsInMedia(url: string, html: HtmlMarks): boolean {
  const u = String(url || '').trim();
  if (!u) return false;
  const tail = u.replace(/^https?:\/\/[^/]+/, '');
  return html.media.some((m) => m.includes(u) || (tail.length > 6 && m.includes(tail)) || m.includes(encodeURIComponent(tail)));
}

const GLOBAL_SKIP = /color|font|radius|mode|theme|css|code|design|weight|scale|tracking|prefill|currency|locale|timezone|analytics|pixel|gtm|seo/i;

/** Calcula la cobertura de editabilidad. Puro: el CLI descarga el HTML y llama a esta función. */
export function auditEditability(payload: DeliveryPayload, pages: AuditPageInput[], opts: AuditOptions = {}): AuditReport {
  const units: UnitReport[] = [];
  const ignore = opts.ignore ? [...DEFAULT_IGNORED_KEYS, ...opts.ignore] : DEFAULT_IGNORED_KEYS;
  const pageReports: AuditReport['pages'] = [];
  const allMarks: HtmlMarks[] = [];

  for (const pg of pages) {
    if (pg.error) {
      pageReports.push({ path: pg.path, pageSlug: pg.pageSlug, error: pg.error, total: 0, covered: 0, pct: 0 });
      continue;
    }
    const html = collectMarks(pg.html);
    allMarks.push(html);
    let pt = 0;
    let pc = 0;
    for (const s of getSections(payload, pg.pageSlug)) {
      const block = s.block || s.data?._block || html.sections[s.key]?.block || null;
      const sectionIgnore = ignore.filter((k) => !k.includes('.') || k.startsWith(`${s.key}.`)).map((k) => (k.startsWith(`${s.key}.`) ? k.slice(s.key.length + 1) : k));
      const expected = expectedSectionFields(s.data || {}, block, payload, sectionIgnore).filter((f) => !sectionIgnore.includes(f.path));
      const rendered = Boolean(html.sections[s.key]);
      const fields: FieldResult[] = expected.map((f) => {
        const covered = rendered && fieldCovered(f, html.sections[s.key]?.fields, html);
        const shown = !covered && (f.type === 'image' ? appearsInMedia(f.value, html) : appearsInText(f.value, html));
        return { ...f, covered, ...(shown ? { shownUnmarked: true } : {}) };
      });
      const covered = fields.filter((f) => f.covered).length;
      pt += fields.length;
      pc += covered;
      units.push({ page: pg.pageSlug, path: pg.path, unit: s.key, block, rendered, total: fields.length, covered, pct: pct(covered, fields.length), fields });
    }
    pageReports.push({ path: pg.path, pageSlug: pg.pageSlug, total: pt, covered: pc, pct: pct(pc, pt) });
  }

  if (opts.extras !== false && allMarks.length) {
    const anyText = (v: string) => allMarks.some((h) => appearsInText(v, h));
    const anyMedia = (v: string) => allMarks.some((h) => appearsInMedia(v, h));
    const globalsMarked = new Set(allMarks.flatMap((h) => [...h.globals]));
    const navMarked = new Set(allMarks.flatMap((h) => [...h.nav]));

    // globales visibles
    const gFields: FieldResult[] = [];
    for (const [k, v] of Object.entries(payload.global || {})) {
      if (typeof v !== 'string' || GLOBAL_SKIP.test(k) || ignore.includes(k) || ignore.includes(`global.${k}`)) continue;
      const s = v.trim();
      if (s.length < 3 || /^#[0-9a-f]{3,8}$/i.test(s)) continue;
      const isMedia = /(url|logo|image|icon|favicon)$/i.test(k) || /\.(svg|png|jpe?g|webp|avif|ico)(\?|$)/i.test(s);
      const shown = isMedia ? anyMedia(s) : anyText(s);
      const covered = globalsMarked.has(k);
      if (!shown && !covered) continue; // no se muestra: no cuenta
      gFields.push({ path: k, type: isMedia ? 'image' : 'text', value: s.slice(0, 80), covered, ...(shown && !covered ? { shownUnmarked: true } : {}) });
    }
    if (gFields.length) units.push(unit('[global]', gFields));

    // navegación
    const nav = (payload.navigation || {}) as Record<string, any>;
    const nFields: FieldResult[] = [];
    const lists: Array<[string, string]> = [
      ['headerLinks', ''],
      ['footerLinks', 'footer.'],
    ];
    for (const [list, prefix] of lists) {
      (Array.isArray(nav[list]) ? nav[list] : []).forEach((l: any, i: number) => {
        if (!l || l.isVisible === false || !str(l.label).trim()) return;
        const keys = prefix ? [`${prefix}${i}`] : [String(i), `header.${i}`];
        const covered = keys.some((k) => navMarked.has(k));
        const shown = anyText(l.label);
        if (!shown && !covered) return;
        nFields.push({ path: `${list}.${i}.label`, type: 'text', value: l.label, covered, ...(shown && !covered ? { shownUnmarked: true } : {}) });
      });
    }
    for (const k of ['headerCtaText']) {
      const v = str(nav[k]).trim();
      if (!v) continue;
      const covered = navMarked.has(k);
      if (!covered && !anyText(v)) continue;
      nFields.push({ path: k, type: 'text', value: v, covered, ...(!covered ? { shownUnmarked: true } : {}) });
    }
    if (nav.promoBanner && nav.promoBanner.enabled !== false) {
      for (const k of ['title', 'description', 'ctaText']) {
        const v = str(nav.promoBanner[k]).trim();
        if (!v) continue;
        const covered = navMarked.has(`promoBanner.${k}`);
        if (!covered && !anyText(v)) continue;
        nFields.push({ path: `promoBanner.${k}`, type: 'text', value: v, covered, ...(!covered ? { shownUnmarked: true } : {}) });
      }
    }
    if (nFields.length) units.push(unit('[nav]', nFields));

    // ítems de colecciones que se muestran
    for (const [col, items] of Object.entries(payload.collections || {})) {
      const iFields: FieldResult[] = [];
      for (const it of (items || []) as CollectionItem[]) {
        if (it.status && it.status !== 'PUBLISHED') continue;
        const ref = `${col}:${it.id}`;
        const marked = new Set<string>();
        for (const h of allMarks) h.items.get(ref)?.forEach((f) => marked.add(f));
        const titleShown = str(it.title).trim().length >= 3 && anyText(it.title);
        if (!titleShown && !allMarks.some((h) => h.items.has(ref))) continue;
        for (const [k, v] of Object.entries(it)) {
          if (k.startsWith('_') || ignore.includes(k) || ['id', 'slug', 'status', 'isFeatured', 'createdAt', 'updatedAt', 'order', 'data'].includes(k)) continue;
          if (typeof v !== 'string' || v.trim().length < 2) continue;
          const t = inferFieldType(v, k);
          if (t === 'color') continue;
          const shown = t === 'image' ? anyMedia(v) : appearsLong(v) && anyText(v);
          const covered = marked.has(k);
          if (!shown && !covered) continue;
          iFields.push({ path: `${it.slug || it.id}.${k}`, type: t, value: v.slice(0, 60), covered, ...(shown && !covered ? { shownUnmarked: true } : {}) });
        }
      }
      if (iFields.length) units.push(unit(`[items:${col}]`, iFields));
    }
  }

  const total = units.reduce((n, u) => n + u.total, 0);
  const covered = units.reduce((n, u) => n + u.covered, 0);
  return { units, pages: pageReports, total, covered, pct: pct(covered, total) };
}

function appearsLong(v: string): boolean {
  // textos muy cortos ("Sí", "M") darían falsos positivos
  return normalizeText(v).length >= 3;
}

function unit(name: string, fields: FieldResult[]): UnitReport {
  const covered = fields.filter((f) => f.covered).length;
  return { page: '*', path: '*', unit: name, block: null, rendered: true, total: fields.length, covered, pct: pct(covered, fields.length), fields };
}

/** Tabla de texto para la terminal. */
export function formatAuditTable(r: AuditReport, { maxMissing = 4 } = {}): string {
  const rows: string[][] = [['Página', 'Sección', 'Bloque', 'Campos', 'Marcados', '%', 'Faltan']];
  for (const u of r.units) {
    const missing = u.fields.filter((f) => !f.covered);
    const list = missing
      .slice(0, maxMissing)
      .map((f) => `${f.path}${f.shownUnmarked ? '*' : ''}`)
      .join(', ');
    rows.push([
      u.page,
      u.unit + (u.rendered ? '' : ' (sin data-section-key)'),
      u.block || '-',
      String(u.total),
      String(u.covered),
      `${u.pct}`,
      list + (missing.length > maxMissing ? ` +${missing.length - maxMissing}` : ''),
    ]);
  }
  const widths = rows[0].map((_, i) => Math.min(i === 6 ? 70 : 34, Math.max(...rows.map((row) => row[i].length))));
  const fmt = (row: string[]) => row.map((c, i) => (c.length > widths[i] ? `${c.slice(0, widths[i] - 1)}…` : c.padEnd(widths[i]))).join('  ');
  const lines = [fmt(rows[0]), widths.map((w) => '-'.repeat(w)).join('  '), ...rows.slice(1).map(fmt)];
  for (const p of r.pages) if (p.error) lines.push(`! ${p.path}: ${p.error}`);
  lines.push('');
  lines.push(`Cobertura total: ${r.covered}/${r.total} = ${r.pct} %   (* = se ve en la página pero no tiene marcado editable)`);
  return lines.join('\n');
}

