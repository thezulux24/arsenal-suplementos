/**
 * Rutas con puntos para campos anidados (§8.1): `headline`, `cta.label`, `items.2.title`.
 * Los segmentos numéricos indexan arreglos. Todas las escrituras son inmutables.
 */

export type ArrayOp = 'add' | 'duplicate' | 'remove' | 'move_up' | 'move_down';

const INDEX = /^\d+$/;

export function splitPath(path: string): string[] {
  return String(path ?? '')
    .split('.')
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

/** Une segmentos ignorando vacíos: joinPath('items', 2, 'title') → "items.2.title". */
export function joinPath(...parts: Array<string | number | null | undefined>): string {
  return parts
    .filter((p) => p !== null && p !== undefined && String(p) !== '')
    .map(String)
    .join('.');
}

export function getPath<T = any>(obj: any, path: string): T | undefined {
  if (!path) return obj;
  let cur = obj;
  for (const k of splitPath(path)) {
    if (cur === null || cur === undefined) return undefined;
    cur = cur[INDEX.test(k) && Array.isArray(cur) ? Number(k) : k];
  }
  return cur as T | undefined;
}

/** Copia con `value` en `path`; crea objetos/arreglos intermedios y conserva los hermanos. */
export function setPath<T = any>(obj: T, path: string, value: any): T {
  const keys = splitPath(path);
  if (!keys.length) return value;
  const rec = (node: any, i: number): any => {
    const k = keys[i];
    const isIdx = INDEX.test(k);
    const base = node === null || node === undefined || typeof node !== 'object' ? (isIdx ? [] : {}) : node;
    const copy: any = Array.isArray(base) ? [...base] : { ...base };
    const key = isIdx && Array.isArray(copy) ? Number(k) : k;
    copy[key] = i === keys.length - 1 ? value : rec(base[key], i + 1);
    return copy;
  };
  return rec(obj, 0);
}

/** Copia sin la clave (o el elemento del arreglo) en `path`. */
export function deletePath<T = any>(obj: T, path: string): T {
  const keys = splitPath(path);
  if (!keys.length || obj === null || obj === undefined) return obj;
  const parentPath = keys.slice(0, -1).join('.');
  const last = keys[keys.length - 1];
  const parent = parentPath ? getPath(obj, parentPath) : obj;
  if (parent === null || parent === undefined || typeof parent !== 'object') return obj;
  let next: any;
  if (Array.isArray(parent) && INDEX.test(last)) next = parent.filter((_, i) => i !== Number(last));
  else {
    next = { ...(parent as any) };
    delete next[last];
  }
  return parentPath ? setPath(obj, parentPath, next) : next;
}

/** Valor vacío con la misma forma que `sample` (para agregar un elemento a un repetidor). */
export function emptyLike(sample: any): any {
  if (Array.isArray(sample)) return [];
  if (sample && typeof sample === 'object') {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(sample)) out[k] = typeof v === 'boolean' ? v : emptyLike(v);
    return out;
  }
  if (typeof sample === 'number') return 0;
  return '';
}

/**
 * Aplica una operación de repetidor (§8.2 ARRAY_ITEM_ACTION) a `data[arrayPath]`.
 * `add` inserta después de `index` (-1 = al inicio) un elemento vacío con la forma de sus hermanos
 * o `template` si se pasa (el portal usa los valores por defecto del catálogo).
 */
export function applyArrayOp<T = any>(data: T, arrayPath: string, index: number, op: ArrayOp, template?: any): T {
  const current = getPath<any[]>(data, arrayPath);
  const list = Array.isArray(current) ? [...current] : [];
  const i = Math.max(-1, Math.min(index, list.length - 1));
  switch (op) {
    case 'add': {
      const sample = template !== undefined ? template : emptyLike(list[i] ?? list[0] ?? '');
      list.splice(i + 1, 0, template !== undefined ? clone(template) : sample);
      break;
    }
    case 'duplicate':
      if (i < 0) return data;
      list.splice(i + 1, 0, clone(list[i]));
      break;
    case 'remove':
      if (i < 0) return data;
      list.splice(i, 1);
      break;
    case 'move_up':
      if (i <= 0) return data;
      [list[i - 1], list[i]] = [list[i], list[i - 1]];
      break;
    case 'move_down':
      if (i < 0 || i >= list.length - 1) return data;
      [list[i + 1], list[i]] = [list[i], list[i + 1]];
      break;
    default:
      return data;
  }
  return setPath(data, arrayPath, list);
}

function clone<T>(v: T): T {
  if (v === undefined) return v;
  try {
    return typeof structuredClone === 'function' ? structuredClone(v) : JSON.parse(JSON.stringify(v));
  } catch {
    return JSON.parse(JSON.stringify(v));
  }
}
