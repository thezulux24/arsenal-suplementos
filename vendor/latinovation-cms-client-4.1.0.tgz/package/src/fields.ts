import type { BlockSchema, FieldSchema, FieldType, LinkValue } from './types.js';
import { BLOCK_SCHEMAS } from './catalog.js';
import { getPath, splitPath } from './paths.js';

/** Texto de un valor primitivo ('' para objetos, null o undefined). */
export function str(v: unknown): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'bigint') return String(v);
  return '';
}

/** true si el valor no aporta nada que mostrar. */
export function isEmptyValue(v: unknown): boolean {
  if (v === null || v === undefined) return true;
  if (typeof v === 'string') return v.trim() === '';
  if (Array.isArray(v)) return v.length === 0;
  if (typeof v === 'object') return Object.values(v as object).every(isEmptyValue);
  return false;
}

// ───────────── imágenes (§8.4) ─────────────

/** `image` → `imageAlt`; `items.0.image` → `items.0.imageAlt`. */
export function imageAltPath(path: string): string {
  return `${path}Alt`;
}

/** `image` → `imageFocal` ("50% 30%", se aplica como object-position). */
export function imageFocalPath(path: string): string {
  return `${path}Focal`;
}

/** true si `key` es un compañero `…Alt`/`…Focal` de otro campo presente en `siblings`. */
export function isImageCompanion(key: string, siblings?: Record<string, any>): boolean {
  const m = key.match(/^(.+?)(Alt|Focal)$/);
  if (!m) return false;
  return siblings ? m[1] in siblings : true;
}

const FOCAL = /^\s*-?\d{1,3}(\.\d+)?%\s+-?\d{1,3}(\.\d+)?%\s*$/;

/** Normaliza un foco ("50% 30%", "50,30", {x,y}) a `object-position` válido o ''. */
export function focalToObjectPosition(v: unknown): string {
  if (!v) return '';
  if (typeof v === 'object') {
    const o = v as { x?: number; y?: number };
    if (typeof o.x === 'number' && typeof o.y === 'number') return `${clampPct(o.x)}% ${clampPct(o.y)}%`;
    return '';
  }
  const s = String(v).trim();
  if (FOCAL.test(s)) return s.split(/\s+/).map((p) => `${clampPct(parseFloat(p))}%`).join(' ');
  const m = s.match(/^(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)$/);
  if (m) return `${clampPct(Number(m[1]))}% ${clampPct(Number(m[2]))}%`;
  if (/^(center|top|bottom|left|right)(\s+(center|top|bottom|left|right))?$/i.test(s)) return s.toLowerCase();
  return '';
}

function clampPct(n: number): number {
  return Math.max(0, Math.min(100, Math.round(n * 10) / 10));
}

export interface ImageFieldValue {
  src: string;
  alt: string;
  objectPosition: string;
}

/**
 * Lee una imagen con sus compañeros: `imageField(data, 'items.0.image')`.
 * Acepta también valores objeto `{ url|src, alt, focal }`.
 */
export function imageField(data: any, path: string, fallbackAlt = ''): ImageFieldValue {
  const raw = getPath(data, path);
  let src = '';
  let alt = '';
  let focal: unknown = '';
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    const o = raw as Record<string, any>;
    src = str(o.url || o.src || o.image);
    alt = str(o.alt);
    focal = o.focal;
  } else src = str(raw);
  alt = str(getPath(data, imageAltPath(path))) || alt || fallbackAlt;
  const fp = focalToObjectPosition(getPath(data, imageFocalPath(path)) || focal);
  return { src, alt, objectPosition: fp };
}

/** Imágenes de un campo galería (texto separado por comas/saltos/`|`, o arreglo de strings/objetos). */
export function galleryField(v: unknown): Array<{ url: string; alt: string }> {
  if (typeof v === 'string')
    return v
      .split(/\s*[\n,|]\s*/)
      .map((s) => s.trim())
      .filter(Boolean)
      .map((url) => ({ url, alt: '' }));
  if (!Array.isArray(v)) return [];
  return v
    .map((it: any) => (typeof it === 'string' ? { url: it, alt: '' } : { url: str(it?.url || it?.src || it?.image), alt: str(it?.alt || it?.title) }))
    .filter((it) => it.url);
}

// ───────────── enlaces ─────────────

/** Acepta `{label,href,newTab}`, `{text,url}` o un string (href). */
export function normalizeLink(v: unknown): LinkValue {
  if (!v) return {};
  if (typeof v === 'string') return { href: v };
  if (typeof v !== 'object') return {};
  const o = v as Record<string, any>;
  return {
    ...o,
    label: str(o.label ?? o.text ?? o.title),
    href: str(o.href ?? o.url ?? o.link),
    newTab: Boolean(o.newTab ?? o.openInNewTab ?? o.target === '_blank'),
  };
}

const SAFE_HREF = /^(https?:|mailto:|tel:|#|\/|\?|whatsapp:|cart:|tracking:)/i;

/** href seguro para el navegador ('' si es javascript:, data:, etc.). Relativos simples se aceptan. */
export function safeHref(href: string | undefined): string {
  const raw = String(href || '').trim();
  if (!raw) return '';
  if (SAFE_HREF.test(raw)) return raw;
  if (/^[a-z0-9][\w-]*(\/|$|#|\?)/i.test(raw) && !/^[a-z][\w+.-]*:/i.test(raw)) return raw;
  return '';
}

// ───────────── esquema del catálogo ─────────────

export function getBlockSchema(block: string | null | undefined): BlockSchema | undefined {
  if (!block) return undefined;
  return BLOCK_SCHEMAS[block];
}

/** Esquema del campo en `path` para un bloque (ignora índices): fieldSchema('faq.accordion', 'items.0.answer'). */
export function fieldSchema(block: string | null | undefined, path: string): FieldSchema | undefined {
  const schema = getBlockSchema(block);
  if (!schema) return undefined;
  let fields: FieldSchema[] | undefined = schema.fields;
  let found: FieldSchema | undefined;
  for (const seg of splitPath(path)) {
    if (/^\d+$/.test(seg)) continue;
    found = fields?.find((f) => f.key === seg);
    if (!found) {
      // compañeros de imagen: imageAlt/imageFocal
      if (/(Alt)$/.test(seg)) return { key: seg, type: 'text', label: 'Texto alternativo' };
      return undefined;
    }
    fields = found.fields;
  }
  return found;
}

const IMG_EXT = /\.(avif|webp|png|jpe?g|gif|svg)(\?|#|$)/i;

/** Tipo probable de un campo sin esquema, por su valor y su nombre. */
export function inferFieldType(value: unknown, key = ''): FieldType {
  const k = key.split('.').pop() || '';
  if (typeof value === 'boolean') return 'boolean';
  if (typeof value === 'number') return 'number';
  if (Array.isArray(value)) {
    if (value.every((x) => typeof x === 'string' && (IMG_EXT.test(x) || /^\/uploads\//.test(x)))) return value.length ? 'gallery' : 'array';
    return 'array';
  }
  if (value && typeof value === 'object') {
    const o = value as Record<string, any>;
    if ('href' in o || 'url' in o) return 'link';
    return 'text';
  }
  const s = str(value);
  if (/^#[0-9a-f]{3,8}$/i.test(s)) return 'color';
  if (/(image|img|photo|foto|logo|avatar|poster|cover|thumbnail|banner)(url)?$/i.test(k) || (IMG_EXT.test(s) && !/\s/.test(s))) return 'image';
  if (/gallery|galeria|images$/i.test(k)) return 'gallery';
  if (/(body|content|description|descripcion|answer|bio|markdown|richtext)$/i.test(k) && /[*#\n\[]/.test(s)) return 'richtext';
  if (s.length > 120 || s.includes('\n')) return 'textarea';
  return 'text';
}

/** Tipo de un campo de sección: esquema del catálogo si existe; si no, inferido del valor. */
export function resolveFieldType(block: string | null | undefined, path: string, value: unknown): FieldType {
  const f = fieldSchema(block, path);
  if (f) return f.type as FieldType;
  return inferFieldType(value, path);
}

// ───────────── Markdown seguro (mismo subconjunto que el renderer del CMS) ─────────────

export function escapeHtml(s: string): string {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function safeMdUrl(url: string): string {
  const u = url.trim();
  return /^(https?:|mailto:|tel:|#|\/)/i.test(u) ? u : '#';
}

function inlineMd(text: string): string {
  let s = escapeHtml(text);
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<em>$2</em>');
  s = s.replace(/(^|[\s(])_([^_\s][^_]*)_/g, '$1<em>$2</em>');
  s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (_m, label, url) => {
    const href = safeMdUrl(String(url).replace(/&amp;/g, '&'));
    const ext = /^https?:/i.test(href);
    return `<a href="${escapeHtml(href)}"${ext ? ' target="_blank" rel="noopener noreferrer"' : ''}>${label}</a>`;
  });
  return s;
}

/** Markdown → HTML seguro: títulos, párrafos, listas, citas, separadores, énfasis y enlaces. */
export function markdownToHtml(md: string): string {
  const src = String(md || '').replace(/\r\n?/g, '\n').trim();
  if (!src) return '';
  const out: string[] = [];
  let para: string[] = [];
  let list: { type: 'ul' | 'ol'; items: string[] } | null = null;
  let quote: string[] = [];
  const flushPara = () => {
    if (para.length) out.push(`<p>${para.map(inlineMd).join('<br />')}</p>`);
    para = [];
  };
  const flushList = () => {
    if (list) out.push(`<${list.type}>${list.items.map((i) => `<li>${inlineMd(i)}</li>`).join('')}</${list.type}>`);
    list = null;
  };
  const flushQuote = () => {
    if (quote.length) out.push(`<blockquote><p>${quote.map(inlineMd).join('<br />')}</p></blockquote>`);
    quote = [];
  };
  const flushAll = () => {
    flushPara();
    flushList();
    flushQuote();
  };
  for (const raw of src.split('\n')) {
    const line = raw.trimEnd();
    if (!line.trim()) {
      flushAll();
      continue;
    }
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    if (h) {
      flushAll();
      const level = Math.min(4, h[1].length + 1);
      out.push(`<h${level}>${inlineMd(h[2])}</h${level}>`);
      continue;
    }
    if (/^(-{3,}|\*{3,})$/.test(line.trim())) {
      flushAll();
      out.push('<hr />');
      continue;
    }
    const q = line.match(/^>\s?(.*)$/);
    if (q) {
      flushPara();
      flushList();
      quote.push(q[1]);
      continue;
    }
    const ul = line.match(/^\s*[-*•]\s+(.*)$/);
    const ol = line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (ul || ol) {
      flushPara();
      flushQuote();
      const type = ul ? 'ul' : 'ol';
      if (!list || list.type !== type) {
        flushList();
        list = { type, items: [] };
      }
      list.items.push((ul || ol)![1]);
      continue;
    }
    flushList();
    flushQuote();
    para.push(line.trim());
  }
  flushAll();
  return out.join('');
}

/** Texto plano de Markdown (para metadescripciones y vistas previas). */
export function markdownToText(md: string): string {
  return String(md || '')
    .replace(/[#>*_`]/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();
}
