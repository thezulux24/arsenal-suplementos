import { INLINE_TYPES, parseItemAttr, parseNavAttr } from './attrs.js';
import type { LivePreviewBridge, NavChangeTarget, SectionTarget } from './live.js';

/**
 * Runtime del lienzo, independiente del framework: todo se decide por el marcado §8.1.
 * Lo usa el provider de React y sirve igual para sitios sin React (`createBuilderRuntime`).
 *
 *  - asigna `data-el-id` deterministas (`<clave>::div.0>h2.1`, como el renderer del CMS) a los
 *    elementos que no traen uno explícito, y envía SECTION_DOM_TREE al portal;
 *  - clic: SELECT_SECTION + SELECT_ELEMENT; imagen/galería/richtext/enlace/select… → FOCUS_FIELD;
 *    ítems → FOCUS_COLLECTION_ITEM; globales → FOCUS_GLOBAL; navegación → FOCUS_NAV;
 *  - edición en línea: al salir de un `[contenteditable]` marcado envía INLINE_*_CHANGE;
 *  - Ctrl/Cmd+Z, Ctrl/Cmd+Shift+Z / Ctrl+Y → HISTORY; arrastre de secciones → REORDER_DROP;
 *  - etiqueta flotante "Cambiar imagen" al pasar sobre imágenes editables.
 */

export interface SelectedElement {
  sectionId: string;
  sectionKey: string;
  elementId: string;
  parentElementId?: string | null;
  tagName: string;
  label: string;
  textPreview: string;
  computedBg: string;
  computedColor: string;
}

export interface DomTreeEntry {
  elementId: string;
  tag: string;
  label: string;
  textPreview: string;
  depth: number;
}

const SKIP_TAGS = new Set(['STYLE', 'SCRIPT', 'TEMPLATE', 'NOSCRIPT']);

function isChrome(el: Element): boolean {
  return el.classList.contains('cms-ui') || el.classList.contains('cms-builder-ui');
}

function textOf(el: HTMLElement, max: number): string {
  return String(el.innerText ?? el.textContent ?? '')
    .trim()
    .replace(/\s+/g, ' ')
    .slice(0, max);
}

function hasBackground(el: HTMLElement): boolean {
  if (typeof getComputedStyle !== 'function') return false;
  const bg = getComputedStyle(el).backgroundColor;
  return Boolean(bg && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)');
}

/**
 * Etiqueta los elementos de cada sección. En el editor, todas; en el sitio público solo las
 * que llevan `data-cms-styled` (tienen `_elementStyles`). Devuelve el árbol por sección.
 */
export function tagSectionElements(root: ParentNode, { isBuilder = false, maxPerSection = 48, maxDepth = 5 } = {}): Record<string, DomTreeEntry[]> {
  const tree: Record<string, DomTreeEntry[]> = {};
  root.querySelectorAll('[data-section-key]').forEach((secEl) => {
    if (!isBuilder && !secEl.hasAttribute('data-cms-styled')) return;
    // secciones anidadas: cada una se recorre por separado
    if (secEl.parentElement?.closest('[data-section-key]')) return;
    const secKey = secEl.getAttribute('data-section-key') || 'sec';
    const list: DomTreeEntry[] = [];
    const walk = (node: Element, prefix: string, depth: number) => {
      Array.from(node.children).forEach((child, idx) => {
        if (isChrome(child) || SKIP_TAGS.has(child.tagName)) return;
        const tag = child.tagName.toLowerCase();
        const path = prefix ? `${prefix}>${tag}.${idx}` : `${tag}.${idx}`;
        const current = child.getAttribute('data-el-id');
        let elId = current || '';
        if (!current || child.hasAttribute('data-el-auto')) {
          elId = `${secKey}::${path}`;
          if (current !== elId) child.setAttribute('data-el-id', elId);
          if (!child.hasAttribute('data-el-auto')) child.setAttribute('data-el-auto', '');
        }
        if (isBuilder && depth <= maxDepth && list.length < maxPerSection) {
          const h = child as HTMLElement;
          const txt = textOf(h, 48);
          const bg = hasBackground(h);
          if (txt || bg || tag === 'img' || tag === 'button' || tag === 'a') {
            const label =
              tag === 'img'
                ? `Imagen: ${(h.getAttribute('alt') || 'Foto').slice(0, 24)}`
                : txt
                ? `${bg ? 'Caja' : tag.toUpperCase()}: "${txt.slice(0, 26)}${txt.length > 26 ? '…' : ''}"`
                : `Contenedor (${tag})`;
            list.push({ elementId: elId, tag, label, textPreview: txt, depth });
          }
        }
        walk(child, path, depth + 1);
      });
    };
    walk(secEl, '', 0);
    tree[secKey] = list;
  });
  return tree;
}

export function describeElement(el: HTMLElement): SelectedElement | null {
  const elementId = el.getAttribute('data-el-id');
  if (!elementId) return null;
  const sec = el.closest('[data-section-key]') as HTMLElement | null;
  const sectionKey = sec?.getAttribute('data-section-key') || '';
  const sectionId = sec?.getAttribute('data-section-id') || `sec-${sectionKey}`;
  const parent = el.parentElement?.closest('[data-el-id]') as HTMLElement | null;
  const parentElementId = parent && sec?.contains(parent) && parent !== sec ? parent.getAttribute('data-el-id') : null;
  const cs = typeof getComputedStyle === 'function' ? getComputedStyle(el) : null;
  const textPreview = textOf(el, 72);
  const tag = el.tagName.toLowerCase();
  const label = textPreview
    ? `${tag === 'div' || tag === 'span' ? 'Caja' : tag.toUpperCase()}: "${textPreview.slice(0, 28)}${textPreview.length > 28 ? '…' : ''}"`
    : tag === 'img'
    ? `Imagen: ${(el.getAttribute('alt') || 'Foto').slice(0, 24)}`
    : `Contenedor (${tag})`;
  return {
    sectionId,
    sectionKey,
    elementId,
    parentElementId,
    tagName: tag,
    label,
    textPreview,
    computedBg: cs?.backgroundColor || 'rgba(23, 20, 18, 0.85)',
    computedColor: cs?.color || '#F5F2EB',
  };
}

/** Elemento a seleccionar al hacer clic: si el texto está dentro de una "caja" con fondo, la caja. */
export function resolveSelectableElement(target: Element): HTMLElement | null {
  const tagged = target.closest('[data-el-id]') as HTMLElement | null;
  if (!tagged || tagged.hasAttribute('data-section-key')) return null;
  if (hasBackground(tagged)) return tagged;
  let cur = tagged.parentElement;
  for (let depth = 0; depth < 2 && cur; depth++) {
    if (cur.hasAttribute('data-section-key')) break;
    if (cur.getAttribute('data-el-id') && hasBackground(cur)) {
      const r = cur.getBoundingClientRect();
      if (r.width < 920 && r.height < 520) return cur;
    }
    cur = cur.parentElement;
  }
  return tagged;
}

export type LocalChange =
  | { kind: 'field'; section: SectionTarget; path: string; value: unknown }
  | { kind: 'global'; fieldKey: string; value: unknown }
  | { kind: 'nav'; target: NavChangeTarget; value: unknown }
  | { kind: 'item'; collection: string; itemId: string; fieldKey: string; value: unknown };

export interface BuilderRuntimeOptions {
  bridge: LivePreviewBridge;
  /** Raíz a observar (por defecto `document`). */
  root?: Document | HTMLElement;
  /** Cambio confirmado en línea, para aplicarlo localmente antes del eco del portal. */
  onLocalChange?: (change: LocalChange) => void;
  onSelectSection?: (sectionKey: string, sectionId: string) => void;
  onSelectElement?: (sel: SelectedElement | null) => void;
  /** Etiquetas de la insignia flotante por tipo. */
  labels?: Partial<Record<string, string>>;
}

export interface BuilderRuntime {
  /** Vuelve a etiquetar y envía SECTION_DOM_TREE. */
  retag(): void;
  selectSection(sectionKey: string): void;
  /** Selecciona y resalta `[data-el-id]` (CMS_SELECT_DOM_ELEMENT). */
  selectElement(elementId: string | null, notify?: boolean): SelectedElement | null;
  destroy(): void;
}

const DEFAULT_LABELS: Record<string, string> = {
  image: 'Cambiar imagen',
  gallery: 'Editar galería',
  richtext: 'Editar texto',
  link: 'Editar enlace',
  select: 'Cambiar opción',
  boolean: 'Cambiar',
  color: 'Cambiar color',
  number: 'Editar número',
  collection: 'Elegir de la colección',
  item: 'Editar ítem',
  global: 'Editar ajuste',
  nav: 'Editar menú',
};

const MARKED = '[data-cms-field],[data-cms-global],[data-cms-nav],[data-cms-item]';

/** Lee el texto editado: sin espacios duros; en una línea salvo `data-cms-multiline`. */
export function readEditableText(el: HTMLElement): string {
  const raw = String(el.innerText ?? el.textContent ?? '').replace(/\u00a0/g, ' ');
  return el.hasAttribute('data-cms-multiline') ? raw.replace(/\n{3,}/g, '\n\n').trim() : raw.replace(/\s*\n\s*/g, ' ').trim();
}

export function createBuilderRuntime(opts: BuilderRuntimeOptions): BuilderRuntime {
  const doc: Document = (opts.root && (opts.root as Document).nodeType === 9 ? (opts.root as Document) : (opts.root as HTMLElement)?.ownerDocument) || document;
  const root: Document | HTMLElement = opts.root || doc;
  const win = doc.defaultView || window;
  const { bridge } = opts;
  const labels = { ...DEFAULT_LABELS, ...(opts.labels || {}) } as Record<string, string>;
  const editStart = new WeakMap<HTMLElement, string>();
  let selectedEl: HTMLElement | null = null;
  let selectedSec: HTMLElement | null = null;
  let dragSourceId = '';
  let dropTarget: HTMLElement | null = null;
  let retagTimer: ReturnType<typeof setTimeout> | undefined;

  const badge = doc.createElement('div');
  badge.className = 'cms-ui cms-ui-badge';
  badge.setAttribute('aria-hidden', 'true');
  badge.style.display = 'none';
  doc.body.appendChild(badge);

  const retag = () => {
    const tree = tagSectionElements(root, { isBuilder: true });
    bridge.post('SECTION_DOM_TREE', { treeBySection: tree });
  };
  const scheduleRetag = () => {
    clearTimeout(retagTimer);
    retagTimer = setTimeout(retag, 160);
  };

  const sectionOf = (el: Element | null) => (el?.closest('[data-section-key]') as HTMLElement | null) || null;
  const sectionTarget = (sec: HTMLElement): SectionTarget & { id: string } => ({
    key: sec.getAttribute('data-section-key') || '',
    id: sec.getAttribute('data-section-id') || `sec-${sec.getAttribute('data-section-key') || ''}`,
  });

  const selectSection = (key: string) => {
    const sec = key ? (doc.querySelector(`[data-section-key="${cssEscape(key)}"]`) as HTMLElement | null) : null;
    if (selectedSec && selectedSec !== sec) selectedSec.removeAttribute('data-cms-selected');
    selectedSec = sec;
    sec?.setAttribute('data-cms-selected', 'true');
  };

  const selectElement = (elementId: string | null, notify = false): SelectedElement | null => {
    selectedEl?.removeAttribute('data-cms-el-selected');
    selectedEl = null;
    if (!elementId) {
      opts.onSelectElement?.(null);
      return null;
    }
    const el = doc.querySelector(`[data-el-id="${cssEscape(elementId)}"]`) as HTMLElement | null;
    if (!el) return null;
    selectedEl = el;
    el.setAttribute('data-cms-el-selected', 'true');
    const sel = describeElement(el);
    if (sel) {
      selectSection(sel.sectionKey);
      opts.onSelectElement?.(sel);
      if (notify) bridge.post('SELECT_ELEMENT', sel as unknown as Record<string, unknown>);
    }
    return sel;
  };

  const focusAction = (marked: HTMLElement): boolean => {
    const item = parseItemAttr(marked.getAttribute('data-cms-item'));
    const field = marked.getAttribute('data-cms-field') || '';
    const type = marked.getAttribute('data-cms-type') || '';
    if (item) {
      bridge.focusCollectionItem(item.collection, item.id, field || undefined);
      return true;
    }
    const global = marked.getAttribute('data-cms-global');
    if (global) {
      bridge.focusGlobal(global);
      return true;
    }
    const nav = parseNavAttr(marked.getAttribute('data-cms-nav'));
    if (nav) {
      if (nav.kind === 'link') bridge.focusNav(nav.index, nav.list === 'footer' ? 'footerLinks' : undefined);
      else bridge.focusNav();
      return true;
    }
    const sec = sectionOf(marked);
    if (sec && field) {
      const t = sectionTarget(sec);
      bridge.focusField(t.key, t.id, field, type && type !== 'item' ? type : undefined);
      return true;
    }
    return false;
  };

  const onClick = (e: MouseEvent) => {
    const t = e.target as HTMLElement | null;
    if (!t || !(t instanceof win.Element)) return;
    if (t.closest('.cms-ui, .cms-builder-ui')) return;
    // En el editor los enlaces no navegan (el iframe se quedaría en otra página).
    const a = t.closest('a[href]');
    if (a) e.preventDefault();
    const editable = t.closest('[contenteditable="true"]') as HTMLElement | null;
    const marked = t.closest(MARKED) as HTMLElement | null;
    const sec = sectionOf(t);
    if (sec) {
      const st = sectionTarget(sec);
      selectSection(st.key);
      opts.onSelectSection?.(st.key, st.id);
      bridge.selectSection(st.key, st.id);
      const chosen = resolveSelectableElement(t);
      if (chosen) {
        selectedEl?.removeAttribute('data-cms-el-selected');
        selectedEl = chosen;
        chosen.setAttribute('data-cms-el-selected', 'true');
        const sel = describeElement(chosen);
        if (sel) {
          opts.onSelectElement?.(sel);
          bridge.post('SELECT_ELEMENT', sel as unknown as Record<string, unknown>);
        }
      }
    }
    // Campo no editable en línea (o clic fuera del texto editable): abrir su editor en el portal.
    if (marked && !(editable && marked.contains(editable)) && !(editable && editable === marked)) {
      const type = marked.getAttribute('data-cms-type') || '';
      if (!INLINE_TYPES.has(type) || !marked.isContentEditable) focusAction(marked);
    }
  };

  const onFocusIn = (e: FocusEvent) => {
    const el = e.target as HTMLElement | null;
    if (el?.isContentEditable && el.matches?.(MARKED)) editStart.set(el, readEditableText(el));
  };

  const commitEditable = (el: HTMLElement) => {
    if (!editStart.has(el)) return;
    const before = editStart.get(el);
    editStart.delete(el);
    const value = readEditableText(el);
    if (value === before) return;
    const field = el.getAttribute('data-cms-field') || '';
    const item = parseItemAttr(el.getAttribute('data-cms-item'));
    if (item) {
      const fieldKey = field || 'title';
      bridge.commitCollectionItem(item.collection, item.id, fieldKey, value);
      opts.onLocalChange?.({ kind: 'item', collection: item.collection, itemId: item.id, fieldKey, value });
      return;
    }
    const global = el.getAttribute('data-cms-global');
    if (global) {
      bridge.commitGlobal(global, value);
      opts.onLocalChange?.({ kind: 'global', fieldKey: global, value });
      return;
    }
    const nav = parseNavAttr(el.getAttribute('data-cms-nav'));
    if (nav) {
      const target: NavChangeTarget =
        nav.kind === 'link'
          ? { linkIndex: nav.index, fieldKey: field || 'label', ...(nav.list === 'footer' ? { navList: 'footerLinks' as const } : {}) }
          : nav.kind === 'promo'
          ? { promoField: nav.field }
          : { fieldKey: nav.field };
      bridge.commitNav(target, value);
      opts.onLocalChange?.({ kind: 'nav', target, value });
      return;
    }
    const sec = sectionOf(el);
    if (!sec || !field) return;
    const st = sectionTarget(sec);
    const widget = field.match(/^widgets\.(\d+)\.([^.]+)$/);
    if (widget) bridge.commitWidgetField(st.key, st.id, Number(widget[1]), widget[2], value);
    else bridge.commitField(st.key, st.id, field, value);
    opts.onLocalChange?.({ kind: 'field', section: st, path: field, value });
  };

  const onFocusOut = (e: FocusEvent) => {
    const el = e.target as HTMLElement | null;
    if (el?.isContentEditable) commitEditable(el);
  };

  const onKeyDown = (e: KeyboardEvent) => {
    const t = e.target as HTMLElement | null;
    const inEditable = Boolean(t && (t.isContentEditable || t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT'));
    if (t?.isContentEditable && e.key === 'Enter' && !e.shiftKey && !t.hasAttribute('data-cms-multiline')) {
      e.preventDefault();
      t.blur();
      return;
    }
    if (t?.isContentEditable && e.key === 'Escape') {
      const before = editStart.get(t);
      if (before !== undefined) {
        t.innerText = before;
        editStart.delete(t);
      }
      t.blur();
      return;
    }
    if (!(e.metaKey || e.ctrlKey) || inEditable) return;
    const key = e.key.toLowerCase();
    if (key !== 'z' && key !== 'y') return;
    e.preventDefault();
    bridge.history(key === 'y' || e.shiftKey ? 'redo' : 'undo');
  };

  const onPaste = (e: ClipboardEvent) => {
    const t = e.target as HTMLElement | null;
    const host = t?.closest?.('[contenteditable="true"]') as HTMLElement | null;
    if (!host) return;
    e.preventDefault();
    const text = e.clipboardData?.getData('text/plain') || '';
    doc.execCommand?.('insertText', false, host.hasAttribute('data-cms-multiline') ? text : text.replace(/\s*\n\s*/g, ' '));
  };

  const hideBadge = () => {
    badge.style.display = 'none';
  };
  const onMouseOver = (e: MouseEvent) => {
    const t = e.target as HTMLElement | null;
    if (!t || !(t instanceof win.Element) || t.closest('.cms-ui')) return hideBadge();
    const marked = t.closest(MARKED) as HTMLElement | null;
    if (!marked || marked.isContentEditable) return hideBadge();
    const type = marked.getAttribute('data-cms-type') || (marked.hasAttribute('data-cms-global') ? 'global' : marked.hasAttribute('data-cms-nav') ? 'nav' : '');
    const isItemMedia = marked.hasAttribute('data-cms-item') && (type === 'image' || type === 'gallery' || marked.tagName === 'IMG');
    const label = isItemMedia ? labels.image : INLINE_TYPES.has(type) ? '' : labels[type] || '';
    if (!label) return hideBadge();
    const r = marked.getBoundingClientRect();
    if (r.width < 24 || r.height < 16) return hideBadge();
    badge.textContent = label;
    badge.style.display = 'block';
    badge.style.top = `${Math.max(4, r.top + 8)}px`;
    badge.style.left = `${Math.max(4, r.left + 8)}px`;
  };

  const onDragStart = (e: DragEvent) => {
    const t = e.target as HTMLElement | null;
    const handle = t?.closest?.('[data-cms-drag-handle]');
    if (!handle) return;
    const sec = sectionOf(handle);
    if (!sec) return;
    dragSourceId = sec.getAttribute('data-section-id') || '';
    sec.setAttribute('data-cms-dragging', 'true');
    try {
      e.dataTransfer?.setData('text/plain', dragSourceId);
      if (e.dataTransfer) e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer?.setDragImage?.(sec, 24, 24);
    } catch {
      /* navegadores sin dataTransfer completo */
    }
  };
  const clearDrop = () => {
    dropTarget?.removeAttribute('data-cms-drop');
    dropTarget = null;
  };
  const onDragOver = (e: DragEvent) => {
    if (!dragSourceId) return;
    const sec = sectionOf(e.target as HTMLElement);
    if (!sec) return;
    e.preventDefault();
    if (dropTarget !== sec) {
      clearDrop();
      dropTarget = sec;
      sec.setAttribute('data-cms-drop', 'true');
    }
  };
  const onDrop = (e: DragEvent) => {
    if (!dragSourceId) return;
    const sec = sectionOf(e.target as HTMLElement);
    e.preventDefault();
    const targetId = sec?.getAttribute('data-section-id') || '';
    if (targetId && targetId !== dragSourceId) bridge.reorderDrop(dragSourceId, targetId);
    onDragEnd();
  };
  const onDragEnd = () => {
    doc.querySelectorAll('[data-cms-dragging]').forEach((el) => el.removeAttribute('data-cms-dragging'));
    clearDrop();
    dragSourceId = '';
  };

  const observer =
    typeof MutationObserver !== 'undefined'
      ? new MutationObserver((records) => {
          if (records.some((r) => r.type === 'childList' && !(r.target as Element)?.closest?.('.cms-ui'))) scheduleRetag();
        })
      : null;
  observer?.observe(root === doc ? doc.body : (root as HTMLElement), { childList: true, subtree: true });

  const target: EventTarget = root;
  target.addEventListener('click', onClick as EventListener, true);
  target.addEventListener('focusin', onFocusIn as EventListener);
  target.addEventListener('focusout', onFocusOut as EventListener);
  target.addEventListener('paste', onPaste as EventListener);
  target.addEventListener('mouseover', onMouseOver as EventListener);
  target.addEventListener('dragstart', onDragStart as EventListener);
  target.addEventListener('dragover', onDragOver as EventListener);
  target.addEventListener('drop', onDrop as EventListener);
  target.addEventListener('dragend', onDragEnd as EventListener);
  win.addEventListener('keydown', onKeyDown);
  win.addEventListener('scroll', hideBadge, { passive: true });
  retag();

  return {
    retag,
    selectSection,
    selectElement,
    destroy() {
      clearTimeout(retagTimer);
      observer?.disconnect();
      target.removeEventListener('click', onClick as EventListener, true);
      target.removeEventListener('focusin', onFocusIn as EventListener);
      target.removeEventListener('focusout', onFocusOut as EventListener);
      target.removeEventListener('paste', onPaste as EventListener);
      target.removeEventListener('mouseover', onMouseOver as EventListener);
      target.removeEventListener('dragstart', onDragStart as EventListener);
      target.removeEventListener('dragover', onDragOver as EventListener);
      target.removeEventListener('drop', onDrop as EventListener);
      target.removeEventListener('dragend', onDragEnd as EventListener);
      win.removeEventListener('keydown', onKeyDown);
      win.removeEventListener('scroll', hideBadge);
      badge.remove();
      selectedEl?.removeAttribute('data-cms-el-selected');
      selectedSec?.removeAttribute('data-cms-selected');
    },
  };
}

function cssEscape(v: string): string {
  if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') return CSS.escape(v);
  return String(v).replace(/["\\]/g, '\\$&');
}
