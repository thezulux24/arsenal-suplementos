/**
 * Estilos del cromo del editor. Solo se inyectan en modo editor (`<html data-cms-builder>`),
 * nunca para visitantes. Personalizables con variables CSS:
 *   --cms-ui-accent, --cms-ui-accent-text, --cms-ui-bg, --cms-ui-fg, --cms-ui-muted, --cms-ui-danger, --cms-ui-font
 */
export const BUILDER_CSS = `
[data-cms-builder]{--cms-ui-accent:#2563EB;--cms-ui-accent-text:#fff;--cms-ui-bg:#0F172A;--cms-ui-fg:#F8FAFC;--cms-ui-muted:#94A3B8;--cms-ui-danger:#F87171;--cms-ui-font:ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}
[data-cms-builder] [data-section-key]{position:relative}
[data-cms-builder] [data-section-key]:hover{outline:1px solid color-mix(in srgb,var(--cms-ui-accent) 45%,transparent);outline-offset:-1px}
[data-cms-builder] [data-section-key][data-cms-hover]{outline:2px solid color-mix(in srgb,var(--cms-ui-accent) 60%,transparent);outline-offset:-2px}
[data-cms-builder] [data-section-key][data-cms-selected]{outline:2px solid var(--cms-ui-accent);outline-offset:-2px}
[data-cms-builder] [data-section-key][data-cms-drop]{box-shadow:inset 0 4px 0 var(--cms-ui-accent)}
[data-cms-builder] [data-section-key][data-cms-dragging]{opacity:.55}
[data-cms-builder] [data-section-key] [data-el-id]:hover{outline:1px dashed color-mix(in srgb,var(--cms-ui-accent) 45%,transparent);outline-offset:1px}
[data-cms-builder] [data-cms-el-selected]{outline:2px solid var(--cms-ui-accent) !important;outline-offset:2px !important}
[data-cms-builder] [contenteditable="true"]{cursor:text;outline-offset:2px;min-width:1ch}
[data-cms-builder] [contenteditable="true"]:focus{outline:2px solid var(--cms-ui-accent) !important;outline-offset:2px}
[data-cms-builder] [contenteditable="true"][data-cms-empty]:empty::before{content:attr(data-cms-placeholder);opacity:.45;font-style:italic}
[data-cms-builder] [data-cms-type="image"],[data-cms-builder] [data-cms-type="gallery"],[data-cms-builder] [data-cms-type="richtext"],[data-cms-builder] [data-cms-item][data-cms-type="image"]{cursor:pointer}
[data-cms-builder] [data-cms-type="image"]:hover,[data-cms-builder] [data-cms-type="gallery"]:hover,[data-cms-builder] [data-cms-type="richtext"]:hover{outline:2px dashed var(--cms-ui-accent);outline-offset:2px}
[data-cms-builder] [data-cms-type="link"],[data-cms-builder] [data-cms-type="item"]{position:relative}
[data-cms-builder] .cms-ui-empty-media{display:flex;align-items:center;justify-content:center;min-height:160px;background:repeating-linear-gradient(45deg,rgba(148,163,184,.14) 0 10px,rgba(148,163,184,.24) 10px 20px);color:var(--cms-ui-muted);font:500 12px/1.2 var(--cms-ui-font)}
[data-cms-builder] .cms-ui-empty-text{opacity:.5;font-style:italic}
.cms-ui{font:500 11px/1.2 var(--cms-ui-font);letter-spacing:0;text-transform:none;color:var(--cms-ui-fg);box-sizing:border-box}
.cms-ui *{box-sizing:border-box}
.cms-ui button,.cms-ui-btn{all:unset;box-sizing:border-box;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:4px;min-width:24px;height:24px;padding:0 6px;border-radius:4px;font:500 11px/1 var(--cms-ui-font);color:inherit}
.cms-ui button:hover{background:rgba(255,255,255,.12)}
.cms-ui button:focus-visible{outline:2px solid var(--cms-ui-accent);outline-offset:1px}
.cms-ui button:disabled{opacity:.3;cursor:default}
.cms-ui button[data-tone="danger"]{color:var(--cms-ui-danger)}
.cms-ui button[data-tone="primary"]{background:var(--cms-ui-accent);color:var(--cms-ui-accent-text)}
.cms-ui-toolbar{position:absolute;top:8px;left:8px;z-index:60;display:inline-flex;align-items:center;gap:2px;padding:3px 4px;background:var(--cms-ui-bg);border-radius:6px;box-shadow:0 6px 20px -6px rgba(0,0,0,.45);opacity:0;transform:translateY(-2px);transition:opacity .12s ease,transform .12s ease;pointer-events:none}
[data-section-key]:hover>.cms-ui-toolbar,[data-section-key][data-cms-selected]>.cms-ui-toolbar,[data-section-key][data-cms-hover]>.cms-ui-toolbar,.cms-ui-toolbar:focus-within{opacity:1;transform:none;pointer-events:auto}
.cms-ui-toolbar .cms-ui-name{padding:0 6px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--cms-ui-fg)}
.cms-ui-toolbar .cms-ui-grip{cursor:grab;color:var(--cms-ui-muted)}
.cms-ui-sep{width:1px;height:16px;background:rgba(255,255,255,.16);margin:0 2px}
.cms-ui-add-after{position:absolute;left:50%;bottom:-13px;transform:translateX(-50%);z-index:61;opacity:0;pointer-events:none;transition:opacity .12s ease}
[data-section-key]:hover>.cms-ui-add-after,[data-section-key][data-cms-selected]>.cms-ui-add-after{opacity:1;pointer-events:auto}
.cms-ui-add-after button,.cms-ui-addbar button{background:var(--cms-ui-accent);color:var(--cms-ui-accent-text);height:26px;padding:0 10px;border-radius:999px;box-shadow:0 4px 14px -4px rgba(0,0,0,.4)}
.cms-ui-addbar{display:flex;justify-content:center;padding:28px 16px}
.cms-ui-item-tools{position:absolute;top:4px;right:4px;z-index:55;display:inline-flex;gap:1px;padding:2px;background:var(--cms-ui-bg);border-radius:5px;opacity:0;pointer-events:none;transition:opacity .12s ease}
[data-cms-type="item"]:hover>.cms-ui-item-tools,.cms-ui-item-tools:focus-within{opacity:1;pointer-events:auto}
.cms-ui-item-tools button{min-width:20px;height:20px;padding:0 4px}
.cms-ui-list-empty{display:flex;justify-content:center;padding:12px}
.cms-ui-list-empty button,.cms-ui-add-item{background:transparent;border:1px dashed var(--cms-ui-accent);color:var(--cms-ui-accent);height:30px;padding:0 12px;border-radius:6px}
.cms-ui-link-btn{position:absolute;top:-10px;right:-10px;z-index:56;opacity:0;pointer-events:none;background:var(--cms-ui-bg);border-radius:999px;transition:opacity .12s ease}
[data-cms-type="link"]:hover>.cms-ui-link-btn,[data-cms-type="link"]:focus-within>.cms-ui-link-btn{opacity:1;pointer-events:auto}
.cms-ui-link-btn button{min-width:20px;height:20px;padding:0}
.cms-ui-badge{position:fixed;z-index:2147483000;pointer-events:none;padding:4px 8px;background:var(--cms-ui-bg);color:var(--cms-ui-fg);border-radius:4px;box-shadow:0 4px 12px -4px rgba(0,0,0,.45)}
.cms-ui-placeholder{display:flex;align-items:center;justify-content:center;min-height:96px;padding:16px;border:1px dashed var(--cms-ui-muted);color:var(--cms-ui-muted)}
.cms-ui-studio{position:fixed;left:50%;bottom:12px;transform:translateX(-50%);z-index:2147482000;max-width:96vw;display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:8px 12px;background:var(--cms-ui-bg);border:1px solid rgba(255,255,255,.1);border-radius:8px;box-shadow:0 18px 40px -12px rgba(0,0,0,.55)}
.cms-ui-studio .cms-ui-group{display:flex;align-items:center;gap:4px;padding-right:8px;border-right:1px solid rgba(255,255,255,.12)}
.cms-ui-studio .cms-ui-group:last-child{border-right:0;padding-right:0}
.cms-ui-studio .cms-ui-label{color:var(--cms-ui-muted)}
.cms-ui-studio .cms-ui-title{max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#93C5FD;font-weight:600}
.cms-ui-studio input[type="color"]{width:24px;height:24px;padding:0;border:1px solid rgba(255,255,255,.2);border-radius:4px;background:transparent;cursor:pointer}
.cms-ui-studio input[type="range"]{width:64px;accent-color:var(--cms-ui-accent)}
.cms-ui-studio button[aria-pressed="true"]{background:var(--cms-ui-accent);color:var(--cms-ui-accent-text)}
@media (prefers-reduced-motion:reduce){.cms-ui,.cms-ui *{transition:none !important}}
`;
