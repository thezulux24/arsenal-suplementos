# @latinovation/cms-client — cómo hacer un sitio 100 % editable

SDK para sitios y storefronts headless (Next.js, React o JavaScript sin framework) que leen su contenido de WebProAI / Latinovation CMS. Con él, un sitio propio se edita desde `/portal` igual que un sitio renderizado por el CMS: textos en línea, imágenes con la mediateca, enlaces, repetidores, productos, globales y menú, estilos por sección y por elemento, mover, duplicar, borrar y agregar bloques, y pedirle cambios a Art.

| Entrada | Qué trae |
|---|---|
| `@latinovation/cms-client` | Núcleo sin dependencias (servidor o navegador): delivery, páginas, secciones, colecciones, rutas con puntos, CSS de sección, design system, marcado §8.1, puente con el portal y runtime del lienzo. |
| `@latinovation/cms-client/react` | Provider, hooks y primitivos editables (`react >= 18`, peer opcional). Todo es componente cliente y seguro en SSR. |
| `@latinovation/cms-client/audit` | Auditoría de editabilidad (la usa `bin/audit-editability.mjs`). |
| `@latinovation/cms-client/builder.css` | Estilos del editor como archivo (el provider ya los inyecta solo en modo editor). |

Contrato del protocolo: [docs/LIVE-PREVIEW.md](../../docs/LIVE-PREVIEW.md) (§8 es v4.1). Contratos de personalización: [docs/EDITING-V4.1.md](../../docs/EDITING-V4.1.md).

## 1. Instalar

El paquete vive en una subcarpeta del monorepo, así que `npm install github:…` no sirve. Dos opciones:

```bash
# A) tarball (recomendado para repos externos y CI)
cd cms-landings/packages/cms-client && npm pack          # → latinovation-cms-client-4.1.0.tgz
cd ../../../mi-sitio && npm install ../cms-landings/packages/cms-client/latinovation-cms-client-4.1.0.tgz

# B) ruta local, copiando (no enlazando) el paquete
npm install --install-links ../cms-landings/packages/cms-client
# o en package.json: "@latinovation/cms-client": "file:../cms-landings/packages/cms-client" + .npmrc con install-links=true
```

Usa `--install-links` (o el tarball) para que no se cargue la copia de React de desarrollo del SDK: con un enlace simbólico `file:` Next resuelve `react` desde `packages/cms-client/node_modules` y aparecen dos Reacts (errores de hooks). `lib/` está versionado: no hace falta compilar para instalar. Requiere Node 18.17+.

## 2. Montar el provider (Next.js App Router)

```tsx
// app/layout.tsx — Server Component
import { fetchDelivery } from '@latinovation/cms-client';
import { CmsProvider } from '@latinovation/cms-client/react';

export default async function Layout({ children }: { children: React.ReactNode }) {
  const initial = await fetchDelivery({ slug: 'mi-sitio', revalidate: 60 }); // ISR + tag "cms:mi-sitio"
  return (
    <html lang="es">
      <body>
        <CmsProvider initial={initial} slug="mi-sitio" allowedOrigins={['http://localhost:3005']}>
          {children}
        </CmsProvider>
      </body>
    </html>
  );
}
```

`<CmsProvider>`:
- Detecta `?preview=1&builder=1&previewToken=…` del portal, descarga borradores con el token (o `previewToken` como prop) y aplica el estado en vivo (`CMS_LIVE_PREVIEW_STATE`). Acepta mensajes solo de `window.parent` con el origen del CMS o de `allowedOrigins`, y responde a ese origen (nunca `*`).
- Emite las variables `--cms-*` del design system (v2 y campos planos v1), los `<link>` de Google Fonts, los `@font-face` propios y `globalCss` saneado. Desactívalo con `designSystem={false}`.
- Solo en modo editor (dentro del iframe del portal) marca `<html data-cms-builder>`, inyecta los estilos del editor y arranca el runtime del lienzo. Para los visitantes no cambia nada: no hay `contentEditable`, listeners ni toolbars.
- Registra la visita (`trackPageview`, por defecto `true`) fuera del editor.
- `pageSlug` / `pathname` / `basePath`: página activa. `<CmsPage pageSlug>` la fija automáticamente; si usas hooks sueltos en rutas dinámicas pasa `pathname={usePathname()}` desde un componente cliente o `pageSlug="/producto"`.

El sitio debe poder embeberse: no envíes `X-Frame-Options: DENY` y, si usas CSP, `frame-ancestors https://webproai.tech`.

## 3. Renderizar páginas con un registro de bloques

```tsx
// components/Blocks.tsx
'use client'; // los componentes del registro no se pueden pasar desde un Server Component
import { CmsPage, CmsContainer, CmsText, CmsImage, CmsLink, CmsList, CmsRichText, defaultRegistry, type CmsRegistry } from '@latinovation/cms-client/react';

function Hero() {
  return (
    <CmsContainer className="hero">
      <CmsText f="headline" as="h1" />
      <CmsText f="subheadline" as="p" />
      <CmsLink f="primaryCta" className="btn" />
      <CmsImage f="image" priority />
    </CmsContainer>
  );
}

function Faq() {
  return (
    <CmsContainer>
      <CmsText f="heading" as="h2" />
      <CmsList f="items" itemAs="details" renderItem={() => (<><CmsText f="question" as="summary" /><CmsRichText f="answer" /></>)} />
    </CmsContainer>
  );
}

const registry: CmsRegistry = { ...defaultRegistry, hero: Hero, 'faq.accordion': Faq };

export function SitePage({ pageSlug }: { pageSlug: string }) {
  return <CmsPage pageSlug={pageSlug} registry={registry} fallback={GenericSection} />;
}
```

`<CmsPage>` pinta las secciones visibles de la página en el orden del CMS. Cada una queda envuelta en `<CmsSection>`. El componente se busca por **clave de sección** (`hero`), luego por **tipo de bloque** (`hero.split`) y luego por **familia** (`hero`), primero en `registry` y después en `defaultRegistry` (ahí se registran bloques compartidos como `layout.composer` con `registerBlock('layout.composer', ComposerBlock)`). Cada componente recibe `{ section, data, index, pageSlug }`. Sin componente: en el editor aparece un aviso; en público no se pinta nada.

`<CmsSection>` (también utilizable solo, con `s={useSection('hero')}`):
- raíz con `id="cms-section-<key>"`, `data-section-key`, `data-section-id`, `data-cms-block`;
- `<style>` con `buildSectionCss`: `_style` (§8.3: colores, fondo con `overlayOpacity`, paddings, `textAlign`, `fontFamily`, `borderRadius`, `minHeight`, `contentWidth`/`maxWidth` vía `data-cms-container`, `hideOnMobile`/`hideOnDesktop`), `_elementStyles` y `_customCss` saneado y acotado a la sección;
- ancla `_style.anchorId` (o el campo `anchor` del catálogo) para enlaces `#…`;
- en el editor: barra con arrastrar (→ `REORDER_DROP`), nombre, subir/bajar (`MOVE_SECTION`), duplicar, eliminar, agregar bloque después (`OPEN_ADD_BLOCK_MODAL { afterSectionId }`) y Art; resaltado al pasar el mouse por la capa en el portal (`CMS_HOVER_SECTION`).

Usa `<CmsContainer>` (o `data-cms-container`) en el contenedor interno para que `contentWidth` funcione.

## 4. Primitivos editables

Todos emiten siempre los atributos §8.1 (`data-cms-field`, `data-cms-type`, `data-el-id`, `data-cms-item`, `data-cms-global`, `data-cms-nav`) y, en el editor, la acción §8.2 correcta. `f` admite rutas con puntos y es relativa dentro de `<CmsList>` (`/ruta` la vuelve absoluta).

| Componente | Marcado | En el editor |
|---|---|---|
| `<CmsText f as? multiline? format? editable? placeholder?>` | `text` / `textarea` | `contentEditable`; Enter confirma (salvo `multiline`), Esc descarta → `INLINE_FIELD_CHANGE { fieldKey: 'items.2.title' }`. Con `format` se abre el inspector. |
| `<CmsRichText f>` | `richtext` | Markdown seguro; clic → `FOCUS_FIELD richtext`. |
| `<CmsImage f alt? as? priority?>` | `image` | Usa `<campo>Alt` y `<campo>Focal` (→ `object-position`). Insignia “Cambiar imagen”; clic → `FOCUS_FIELD image` (mediateca). `as={Image}` para `next/image`. |
| `<CmsGallery f renderImage?>` | `gallery` | Clic → `FOCUS_FIELD gallery`. |
| `<CmsLink f>` o `<CmsLink labelField hrefField>` | `link` + `f.label` | Etiqueta en línea; botón 🔗 → `FOCUS_FIELD link`. Los enlaces no navegan dentro del editor. |
| `<CmsList f renderItem itemAs? wrap? max?>` | `array` + `item` por elemento | Mini barra subir/bajar/duplicar/agregar/quitar → `ARRAY_ITEM_ACTION`; vacío: “Agregar elemento”. |
| `<CmsField f type?>` | según esquema | Despacha por el tipo del catálogo (o inferido del valor). |
| `<CmsItem item collection?>`, `<CmsItemText item? f format?>`, `<CmsItemImage item? f?>` | `data-cms-item="col:id"` | Texto en línea → `INLINE_COLLECTION_ITEM_CHANGE`; imagen o campo con formato → `FOCUS_COLLECTION_ITEM`. |
| `<CmsAddItem collection? category?>` | — | Solo editor → `CREATE_COLLECTION_ITEM`. |
| `<CmsGlobalText f>`, `<CmsGlobalImage f>` | `data-cms-global` | `INLINE_GLOBAL_CHANGE` / `FOCUS_GLOBAL`. |
| `<CmsNav list>`, `<CmsNavLink link list?>`, `<CmsNavText f promo?>` | `data-cms-nav="2"`, `footer.1`, `headerCtaText`, `promoBanner.title` | `INLINE_NAV_CHANGE` (etiqueta) / `FOCUS_NAV`. |
| `useElementId('tarjeta')` | `data-el-id="<key>::tarjeta"` | Id estable para estilos por elemento en tus propios nodos. |

Los demás elementos de la sección reciben `data-el-id` posicionales (`<key>::div.0>h2.1`, como el renderer del CMS) al montar; al hacer clic se envía `SELECT_SECTION` + `SELECT_ELEMENT` y aparece la barra de estilo por elemento (fondo y opacidad, texto, posición, mover, caja padre, Art, restablecer → `INLINE_ELEMENT_STYLE_CHANGE`). El árbol se envía con `SECTION_DOM_TREE`. Ctrl/Cmd+Z y Ctrl/Cmd+Shift+Z (o Ctrl+Y) → `HISTORY`. Todo cambio se aplica localmente al instante y el portal lo confirma con su estado en vivo.

## 5. Hooks

| Hook | Devuelve |
|---|---|
| `useCms()` | `{ payload, isBuilder, isPreview, pageSlug, slug, cmsUrl, selectedKey, selectedElement, bridge, actions, … }` (más `selectSection`, `commitField`, `commitWidgetField`, `commitGlobal`, `post` de v4.0). |
| `useSection(key)` / `useSection(pageSlug, key)`, `useSections(pageSlug?)`, `useCurrentSection()` | Secciones del payload en vivo. |
| `useProducts(opts)`, `useProduct(slug)`, `useItem(collection, slug)` | Ítems en vivo (reflejan ediciones del portal). |
| `useItemRoute(collection, item, { pattern? })` | `/<routeBase>/<slug>` o el patrón. |
| `useCollectionQuery({ collection, filters, sort, page, pageSize, search })` | `{ items, total, page, pageCount, facets, setFilter, setSearch, setSort, setPage, setQuery, reset }`. Filtros: valor exacto o lista (select), `{ min, max }` (rango), booleano; facetas según `collectionDefinitions[col].filters`. |
| `useGlobal(path, fallback)`, `useNavLinks(list)` | Globales y menú. |
| `useLivePreview(initial, opts)` | El estado del provider sin provider. |

## 6. Núcleo (sin React)

```ts
import {
  fetchDelivery, tryFetchDelivery, getSections, getSection, getProducts, getCategories, formatPrice, mediaUrl,
  pageSlugFromPath, getItemRoute, matchItemRoute, queryCollection, fetchItem,
  getPath, setPath, deletePath, applyArrayOp, imageField, normalizeLink, fieldSchema,
  buildSectionCss, scopeCss, sanitizeCss, sectionAnchor, editAttrs, sectionAttrs,
  designSystemToCssVars, designSystemFontLinks, designSystemToCss,
  createLivePreviewBridge, createBuilderRuntime, applyLiveState, readPreviewParams,
} from '@latinovation/cms-client';
```

| Grupo | Funciones |
|---|---|
| Delivery | `fetchDelivery({ slug \| host, baseUrl, preview, previewToken, revalidate, tags })` (lanza `CmsDeliveryError`), `tryFetchDelivery`, `deliveryUrl`. |
| Páginas | `getPage`, `getSections(p, page, { includeHidden })` (visibles y ordenadas), `getSection`, `findSectionsByBlock`, `pageSlugFromPath(pathname, p, basePath)`. |
| Colecciones | `getCollection`, `getStoreCollectionSlug`, `getProducts`, `getProduct`, `getCategories`, `normalizeProduct`, `productPrice`, `formatPrice`, `getItem`, `getItemRoute`, `matchItemRoute`, `queryCollection`, `fetchItem` (`GET /api/v1/delivery/:slug/collections/:col/:item`). |
| Campos | `getPath`, `setPath`, `deletePath`, `joinPath`, `applyArrayOp`, `imageField` (Alt/Focal §8.4), `galleryField`, `normalizeLink`, `safeHref`, `fieldSchema(block, path)`, `resolveFieldType`, `markdownToHtml`. |
| Estilos | `buildSectionCss(section, { isBuilder })`, `buildSectionsCss`, `buildSectionStyleCss`, `buildElementStylesCss`, `scopeCss`, `sanitizeCss`, `sectionAnchor`. |
| Design system | `designSystemToCssVars(ds)`, `designSystemFontLinks(ds)`, `designSystemFontFaces`, `designSystemToCss(ds, ':root')`. |
| Marcado | `editAttrs({ field, type, item, global, nav, elId })`, `sectionAttrs`, `elementId`, `parseItemAttr`, `parseNavAttr`. |
| Portal | `createLivePreviewBridge` (todas las acciones §3 y §8.2 como métodos), `applyLiveState`, `readPreviewParams`, `applyFieldChange` y demás cambios locales, `createBuilderRuntime({ bridge })`, `tagSectionElements`, `BUILDER_CSS`. |

Sitio sin React: renderiza el HTML con los atributos de `editAttrs`/`sectionAttrs` y en el navegador:

```js
const { builder } = readPreviewParams();
const bridge = createLivePreviewBridge({ cmsUrl: 'https://webproai.tech', onState: (msg) => render(applyLiveState(payload, msg, '/')) });
if (builder && window.parent !== window) {
  document.documentElement.setAttribute('data-cms-builder', '');
  document.head.insertAdjacentHTML('beforeend', `<style>${BUILDER_CSS}</style>`);
  createBuilderRuntime({ bridge }); // clics, edición en línea, FOCUS_*, HISTORY, arrastre, SECTION_DOM_TREE
}
```

## 7. Auditar la editabilidad

```bash
node packages/cms-client/bin/audit-editability.mjs --slug mi-sitio --url https://mi-sitio.com --item-route "/producto/:slug"
# opciones: --min 95 · --json · --pages /,/contacto · --ignore campo,seccion.ruta · --no-extras · --cms https://webproai.tech
```

Hace solo GET públicos: delivery del CMS y el HTML de cada página (más un ítem de muestra por `--item-route` o por `routeBase`). Por cada sección visible compara los campos con valor (esquema del catálogo; sin esquema, inferidos del dato, incluidas referencias a ítems) con el marcado del HTML del servidor; cuenta también globales, menú e ítems de colecciones que se ven en la página. Marca con `*` lo que se ve pero no tiene marcado. Sale con 1 bajo `--min` (95 %) y 2 si no pudo auditar. Los campos de configuración (`tone`, `anchor`, `formName`, `href` sueltos…) no cuentan.

## 8. Revalidar al publicar

Al publicar, el backend hace `POST` a `Project.webhookUrl` con `{ event: 'project.published', projectSlug }` y la cabecera `x-cms-webhook-secret`. Un route handler que verifique el secreto y llame a `revalidateTag('cms:<slug>')` invalida lo que `fetchDelivery` cacheó (ver `examples/next-app/app/api/revalidate/route.ts`).

## 9. Ejemplo listo para copiar

[`examples/next-app/`](examples/next-app): Next.js 15 App Router con `CmsPage` + registro (portada, preguntas frecuentes y catálogo con filtros/paginación), detalle de producto, cabecera con globales y menú, webhook de revalidación y estilos solo con `--cms-*`.

```bash
cd packages/cms-client/examples/next-app && npm install && CMS_SLUG=mi-sitio npm run dev
```

## Desarrollo del SDK

```bash
npm run build          # limpia lib/, compila (ESM + .d.ts) y escribe lib/builder.css
npm test               # node --test: núcleo, React (renderToString), runtime (linkedom), auditoría (fixtures + servidor local)
npm run sync-catalog   # regenera src/catalog.ts desde shared/blocks.catalog.json
```

Compatibilidad: las exportaciones de v4.0 se mantienen (`CmsSection s`, `CmsText s f widget`, `cmsSectionProps`, `useLivePreview`, `commitField`…). Cambio visible: los atributos de marcado ahora se emiten también fuera del editor, y `INLINE_FIELD_CHANGE` envía la ruta completa (`items.2.title`) como `fieldKey` según §8.2.
